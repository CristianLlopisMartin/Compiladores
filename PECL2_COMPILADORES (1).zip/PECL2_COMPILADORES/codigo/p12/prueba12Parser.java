// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class prueba12Parser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IMGDIM=1, SHPDIM=2, LINEA=3, DELINICIO=4, DELFINAL=5, NEWLINE=6, NUMEROS=7, 
		FORMAS=8, SEPARADORES=9, WS=10;
	public static final int
		RULE_prog = 0, RULE_separadores = 1, RULE_figuras = 2, RULE_expr = 3, 
		RULE_delinicio = 4, RULE_delfinal = 5, RULE_inicio = 6, RULE_lineaformas = 7, 
		RULE_formas = 8;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "separadores", "figuras", "expr", "delinicio", "delfinal", "inicio", 
			"lineaformas", "formas"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'imgdim:'", "'shpdim:'", null, null, null, null, null, null, null, 
			"' '"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IMGDIM", "SHPDIM", "LINEA", "DELINICIO", "DELFINAL", "NEWLINE", 
			"NUMEROS", "FORMAS", "SEPARADORES", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public prueba12Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public List<InicioContext> inicio() {
			return getRuleContexts(InicioContext.class);
		}
		public InicioContext inicio(int i) {
			return getRuleContext(InicioContext.class,i);
		}
		public List<FormasContext> formas() {
			return getRuleContexts(FormasContext.class);
		}
		public FormasContext formas(int i) {
			return getRuleContext(FormasContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(prueba12Parser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(prueba12Parser.NEWLINE, i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterProg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitProg(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMGDIM || _la==DELINICIO) {
				{
				{
				setState(20);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case IMGDIM:
					{
					setState(18);
					inicio();
					}
					break;
				case DELINICIO:
					{
					setState(19);
					formas();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(25);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(22);
					match(NEWLINE);
					}
					}
					setState(27);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(32);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SeparadoresContext extends ParserRuleContext {
		public TerminalNode SEPARADORES() { return getToken(prueba12Parser.SEPARADORES, 0); }
		public SeparadoresContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_separadores; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterSeparadores(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitSeparadores(this);
		}
	}

	public final SeparadoresContext separadores() throws RecognitionException {
		SeparadoresContext _localctx = new SeparadoresContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_separadores);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(33);
			match(SEPARADORES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FigurasContext extends ParserRuleContext {
		public TerminalNode FORMAS() { return getToken(prueba12Parser.FORMAS, 0); }
		public FigurasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figuras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterFiguras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitFiguras(this);
		}
	}

	public final FigurasContext figuras() throws RecognitionException {
		FigurasContext _localctx = new FigurasContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_figuras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(35);
			match(FORMAS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public TerminalNode NUMEROS() { return getToken(prueba12Parser.NUMEROS, 0); }
		public FigurasContext figuras() {
			return getRuleContext(FigurasContext.class,0);
		}
		public SeparadoresContext separadores() {
			return getRuleContext(SeparadoresContext.class,0);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitExpr(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_expr);
		try {
			setState(40);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NUMEROS:
				enterOuterAlt(_localctx, 1);
				{
				setState(37);
				match(NUMEROS);
				}
				break;
			case FORMAS:
				enterOuterAlt(_localctx, 2);
				{
				setState(38);
				figuras();
				}
				break;
			case SEPARADORES:
				enterOuterAlt(_localctx, 3);
				{
				setState(39);
				separadores();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DelinicioContext extends ParserRuleContext {
		public TerminalNode DELINICIO() { return getToken(prueba12Parser.DELINICIO, 0); }
		public DelinicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delinicio; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterDelinicio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitDelinicio(this);
		}
	}

	public final DelinicioContext delinicio() throws RecognitionException {
		DelinicioContext _localctx = new DelinicioContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_delinicio);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(42);
			match(DELINICIO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DelfinalContext extends ParserRuleContext {
		public TerminalNode DELFINAL() { return getToken(prueba12Parser.DELFINAL, 0); }
		public DelfinalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delfinal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterDelfinal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitDelfinal(this);
		}
	}

	public final DelfinalContext delfinal() throws RecognitionException {
		DelfinalContext _localctx = new DelfinalContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_delfinal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(44);
			match(DELFINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InicioContext extends ParserRuleContext {
		public TerminalNode IMGDIM() { return getToken(prueba12Parser.IMGDIM, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SHPDIM() { return getToken(prueba12Parser.SHPDIM, 0); }
		public InicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inicio; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterInicio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitInicio(this);
		}
	}

	public final InicioContext inicio() throws RecognitionException {
		InicioContext _localctx = new InicioContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_inicio);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(46);
			match(IMGDIM);
			setState(50);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(47);
					expr();
					}
					} 
				}
				setState(52);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			setState(53);
			expr();
			setState(54);
			match(SHPDIM);
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 896L) != 0) {
				{
				{
				setState(55);
				expr();
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LineaformasContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LINEA() { return getToken(prueba12Parser.LINEA, 0); }
		public LineaformasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lineaformas; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterLineaformas(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitLineaformas(this);
		}
	}

	public final LineaformasContext lineaformas() throws RecognitionException {
		LineaformasContext _localctx = new LineaformasContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_lineaformas);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(62); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(61);
					expr();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(64); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(67);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LINEA) {
				{
				setState(66);
				match(LINEA);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormasContext extends ParserRuleContext {
		public DelinicioContext delinicio() {
			return getRuleContext(DelinicioContext.class,0);
		}
		public DelfinalContext delfinal() {
			return getRuleContext(DelfinalContext.class,0);
		}
		public List<LineaformasContext> lineaformas() {
			return getRuleContexts(LineaformasContext.class);
		}
		public LineaformasContext lineaformas(int i) {
			return getRuleContext(LineaformasContext.class,i);
		}
		public FormasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formas; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).enterFormas(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof prueba12Listener ) ((prueba12Listener)listener).exitFormas(this);
		}
	}

	public final FormasContext formas() throws RecognitionException {
		FormasContext _localctx = new FormasContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_formas);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(69);
			delinicio();
			setState(71); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(70);
				lineaformas();
				}
				}
				setState(73); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 896L) != 0 );
			setState(75);
			delfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\nN\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0001\u0000\u0001\u0000\u0003\u0000\u0015\b\u0000\u0001\u0000"+
		"\u0005\u0000\u0018\b\u0000\n\u0000\f\u0000\u001b\t\u0000\u0005\u0000\u001d"+
		"\b\u0000\n\u0000\f\u0000 \t\u0000\u0001\u0001\u0001\u0001\u0001\u0002"+
		"\u0001\u0002\u0001\u0003\u0001\u0003\u0001\u0003\u0003\u0003)\b\u0003"+
		"\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0006\u0001\u0006"+
		"\u0005\u00061\b\u0006\n\u0006\f\u00064\t\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0005\u00069\b\u0006\n\u0006\f\u0006<\t\u0006\u0001\u0007"+
		"\u0004\u0007?\b\u0007\u000b\u0007\f\u0007@\u0001\u0007\u0003\u0007D\b"+
		"\u0007\u0001\b\u0001\b\u0004\bH\b\b\u000b\b\f\bI\u0001\b\u0001\b\u0001"+
		"\b\u0000\u0000\t\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0000\u0000"+
		"N\u0000\u001e\u0001\u0000\u0000\u0000\u0002!\u0001\u0000\u0000\u0000\u0004"+
		"#\u0001\u0000\u0000\u0000\u0006(\u0001\u0000\u0000\u0000\b*\u0001\u0000"+
		"\u0000\u0000\n,\u0001\u0000\u0000\u0000\f.\u0001\u0000\u0000\u0000\u000e"+
		">\u0001\u0000\u0000\u0000\u0010E\u0001\u0000\u0000\u0000\u0012\u0015\u0003"+
		"\f\u0006\u0000\u0013\u0015\u0003\u0010\b\u0000\u0014\u0012\u0001\u0000"+
		"\u0000\u0000\u0014\u0013\u0001\u0000\u0000\u0000\u0015\u0019\u0001\u0000"+
		"\u0000\u0000\u0016\u0018\u0005\u0006\u0000\u0000\u0017\u0016\u0001\u0000"+
		"\u0000\u0000\u0018\u001b\u0001\u0000\u0000\u0000\u0019\u0017\u0001\u0000"+
		"\u0000\u0000\u0019\u001a\u0001\u0000\u0000\u0000\u001a\u001d\u0001\u0000"+
		"\u0000\u0000\u001b\u0019\u0001\u0000\u0000\u0000\u001c\u0014\u0001\u0000"+
		"\u0000\u0000\u001d \u0001\u0000\u0000\u0000\u001e\u001c\u0001\u0000\u0000"+
		"\u0000\u001e\u001f\u0001\u0000\u0000\u0000\u001f\u0001\u0001\u0000\u0000"+
		"\u0000 \u001e\u0001\u0000\u0000\u0000!\"\u0005\t\u0000\u0000\"\u0003\u0001"+
		"\u0000\u0000\u0000#$\u0005\b\u0000\u0000$\u0005\u0001\u0000\u0000\u0000"+
		"%)\u0005\u0007\u0000\u0000&)\u0003\u0004\u0002\u0000\')\u0003\u0002\u0001"+
		"\u0000(%\u0001\u0000\u0000\u0000(&\u0001\u0000\u0000\u0000(\'\u0001\u0000"+
		"\u0000\u0000)\u0007\u0001\u0000\u0000\u0000*+\u0005\u0004\u0000\u0000"+
		"+\t\u0001\u0000\u0000\u0000,-\u0005\u0005\u0000\u0000-\u000b\u0001\u0000"+
		"\u0000\u0000.2\u0005\u0001\u0000\u0000/1\u0003\u0006\u0003\u00000/\u0001"+
		"\u0000\u0000\u000014\u0001\u0000\u0000\u000020\u0001\u0000\u0000\u0000"+
		"23\u0001\u0000\u0000\u000035\u0001\u0000\u0000\u000042\u0001\u0000\u0000"+
		"\u000056\u0003\u0006\u0003\u00006:\u0005\u0002\u0000\u000079\u0003\u0006"+
		"\u0003\u000087\u0001\u0000\u0000\u00009<\u0001\u0000\u0000\u0000:8\u0001"+
		"\u0000\u0000\u0000:;\u0001\u0000\u0000\u0000;\r\u0001\u0000\u0000\u0000"+
		"<:\u0001\u0000\u0000\u0000=?\u0003\u0006\u0003\u0000>=\u0001\u0000\u0000"+
		"\u0000?@\u0001\u0000\u0000\u0000@>\u0001\u0000\u0000\u0000@A\u0001\u0000"+
		"\u0000\u0000AC\u0001\u0000\u0000\u0000BD\u0005\u0003\u0000\u0000CB\u0001"+
		"\u0000\u0000\u0000CD\u0001\u0000\u0000\u0000D\u000f\u0001\u0000\u0000"+
		"\u0000EG\u0003\b\u0004\u0000FH\u0003\u000e\u0007\u0000GF\u0001\u0000\u0000"+
		"\u0000HI\u0001\u0000\u0000\u0000IG\u0001\u0000\u0000\u0000IJ\u0001\u0000"+
		"\u0000\u0000JK\u0001\u0000\u0000\u0000KL\u0003\n\u0005\u0000L\u0011\u0001"+
		"\u0000\u0000\u0000\t\u0014\u0019\u001e(2:@CI";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}