// Generated from /usr/local/Cellar/antlr/4.11.1/bin/p12/prueba12.g4 by ANTLR 4.9.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class prueba12Parser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IMGDIM=1, SHPDIM=2, LINEA=3, DELINICIO=4, DELFINAL=5, NEWLINE=6, NUMEROS=7, 
		FORMAS=8, SEPARADORES=9, WS=10;
	public static final int
		RULE_prog = 0, RULE_separadores = 1, RULE_figuras = 2, RULE_expr = 3, 
		RULE_delinicio = 4, RULE_delfinal = 5, RULE_inicio = 6, RULE_lineaformas = 7, 
		RULE_formas = 8;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "separadores", "figuras", "expr", "delinicio", "delfinal", "inicio", 
			"lineaformas", "formas"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'imgdim:'", "'shpdim:'", null, null, null, null, null, null, null, 
			"' '"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IMGDIM", "SHPDIM", "LINEA", "DELINICIO", "DELFINAL", "NEWLINE", 
			"NUMEROS", "FORMAS", "SEPARADORES", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "prueba12.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public prueba12Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ProgContext extends ParserRuleContext {
		public List<InicioContext> inicio() {
			return getRuleContexts(InicioContext.class);
		}
		public InicioContext inicio(int i) {
			return getRuleContext(InicioContext.class,i);
		}
		public List<FormasContext> formas() {
			return getRuleContexts(FormasContext.class);
		}
		public FormasContext formas(int i) {
			return getRuleContext(FormasContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(prueba12Parser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(prueba12Parser.NEWLINE, i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMGDIM || _la==DELINICIO) {
				{
				{
				setState(20);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case IMGDIM:
					{
					setState(18);
					inicio();
					}
					break;
				case DELINICIO:
					{
					setState(19);
					formas();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(25);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(22);
					match(NEWLINE);
					}
					}
					setState(27);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(32);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SeparadoresContext extends ParserRuleContext {
		public TerminalNode SEPARADORES() { return getToken(prueba12Parser.SEPARADORES, 0); }
		public SeparadoresContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_separadores; }
	}

	public final SeparadoresContext separadores() throws RecognitionException {
		SeparadoresContext _localctx = new SeparadoresContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_separadores);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(33);
			match(SEPARADORES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FigurasContext extends ParserRuleContext {
		public TerminalNode FORMAS() { return getToken(prueba12Parser.FORMAS, 0); }
		public FigurasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figuras; }
	}

	public final FigurasContext figuras() throws RecognitionException {
		FigurasContext _localctx = new FigurasContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_figuras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(35);
			match(FORMAS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public TerminalNode NUMEROS() { return getToken(prueba12Parser.NUMEROS, 0); }
		public FigurasContext figuras() {
			return getRuleContext(FigurasContext.class,0);
		}
		public SeparadoresContext separadores() {
			return getRuleContext(SeparadoresContext.class,0);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_expr);
		try {
			setState(40);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NUMEROS:
				enterOuterAlt(_localctx, 1);
				{
				setState(37);
				match(NUMEROS);
				}
				break;
			case FORMAS:
				enterOuterAlt(_localctx, 2);
				{
				setState(38);
				figuras();
				}
				break;
			case SEPARADORES:
				enterOuterAlt(_localctx, 3);
				{
				setState(39);
				separadores();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DelinicioContext extends ParserRuleContext {
		public TerminalNode DELINICIO() { return getToken(prueba12Parser.DELINICIO, 0); }
		public DelinicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delinicio; }
	}

	public final DelinicioContext delinicio() throws RecognitionException {
		DelinicioContext _localctx = new DelinicioContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_delinicio);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(42);
			match(DELINICIO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DelfinalContext extends ParserRuleContext {
		public TerminalNode DELFINAL() { return getToken(prueba12Parser.DELFINAL, 0); }
		public DelfinalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delfinal; }
	}

	public final DelfinalContext delfinal() throws RecognitionException {
		DelfinalContext _localctx = new DelfinalContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_delfinal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(44);
			match(DELFINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InicioContext extends ParserRuleContext {
		public TerminalNode IMGDIM() { return getToken(prueba12Parser.IMGDIM, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SHPDIM() { return getToken(prueba12Parser.SHPDIM, 0); }
		public InicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inicio; }
	}

	public final InicioContext inicio() throws RecognitionException {
		InicioContext _localctx = new InicioContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_inicio);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(46);
			match(IMGDIM);
			setState(50);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(47);
					expr();
					}
					} 
				}
				setState(52);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			setState(53);
			expr();
			setState(54);
			match(SHPDIM);
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << NUMEROS) | (1L << FORMAS) | (1L << SEPARADORES))) != 0)) {
				{
				{
				setState(55);
				expr();
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LineaformasContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LINEA() { return getToken(prueba12Parser.LINEA, 0); }
		public LineaformasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lineaformas; }
	}

	public final LineaformasContext lineaformas() throws RecognitionException {
		LineaformasContext _localctx = new LineaformasContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_lineaformas);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(62); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(61);
					expr();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(64); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(67);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LINEA) {
				{
				setState(66);
				match(LINEA);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FormasContext extends ParserRuleContext {
		public DelinicioContext delinicio() {
			return getRuleContext(DelinicioContext.class,0);
		}
		public DelfinalContext delfinal() {
			return getRuleContext(DelfinalContext.class,0);
		}
		public List<LineaformasContext> lineaformas() {
			return getRuleContexts(LineaformasContext.class);
		}
		public LineaformasContext lineaformas(int i) {
			return getRuleContext(LineaformasContext.class,i);
		}
		public FormasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formas; }
	}

	public final FormasContext formas() throws RecognitionException {
		FormasContext _localctx = new FormasContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_formas);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(69);
			delinicio();
			setState(71); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(70);
				lineaformas();
				}
				}
				setState(73); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << NUMEROS) | (1L << FORMAS) | (1L << SEPARADORES))) != 0) );
			setState(75);
			delfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\fP\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\3\2\3\2\5\2"+
		"\27\n\2\3\2\7\2\32\n\2\f\2\16\2\35\13\2\7\2\37\n\2\f\2\16\2\"\13\2\3\3"+
		"\3\3\3\4\3\4\3\5\3\5\3\5\5\5+\n\5\3\6\3\6\3\7\3\7\3\b\3\b\7\b\63\n\b\f"+
		"\b\16\b\66\13\b\3\b\3\b\3\b\7\b;\n\b\f\b\16\b>\13\b\3\t\6\tA\n\t\r\t\16"+
		"\tB\3\t\5\tF\n\t\3\n\3\n\6\nJ\n\n\r\n\16\nK\3\n\3\n\3\n\2\2\13\2\4\6\b"+
		"\n\f\16\20\22\2\2\2P\2 \3\2\2\2\4#\3\2\2\2\6%\3\2\2\2\b*\3\2\2\2\n,\3"+
		"\2\2\2\f.\3\2\2\2\16\60\3\2\2\2\20@\3\2\2\2\22G\3\2\2\2\24\27\5\16\b\2"+
		"\25\27\5\22\n\2\26\24\3\2\2\2\26\25\3\2\2\2\27\33\3\2\2\2\30\32\7\b\2"+
		"\2\31\30\3\2\2\2\32\35\3\2\2\2\33\31\3\2\2\2\33\34\3\2\2\2\34\37\3\2\2"+
		"\2\35\33\3\2\2\2\36\26\3\2\2\2\37\"\3\2\2\2 \36\3\2\2\2 !\3\2\2\2!\3\3"+
		"\2\2\2\" \3\2\2\2#$\7\13\2\2$\5\3\2\2\2%&\7\n\2\2&\7\3\2\2\2\'+\7\t\2"+
		"\2(+\5\6\4\2)+\5\4\3\2*\'\3\2\2\2*(\3\2\2\2*)\3\2\2\2+\t\3\2\2\2,-\7\6"+
		"\2\2-\13\3\2\2\2./\7\7\2\2/\r\3\2\2\2\60\64\7\3\2\2\61\63\5\b\5\2\62\61"+
		"\3\2\2\2\63\66\3\2\2\2\64\62\3\2\2\2\64\65\3\2\2\2\65\67\3\2\2\2\66\64"+
		"\3\2\2\2\678\5\b\5\28<\7\4\2\29;\5\b\5\2:9\3\2\2\2;>\3\2\2\2<:\3\2\2\2"+
		"<=\3\2\2\2=\17\3\2\2\2><\3\2\2\2?A\5\b\5\2@?\3\2\2\2AB\3\2\2\2B@\3\2\2"+
		"\2BC\3\2\2\2CE\3\2\2\2DF\7\5\2\2ED\3\2\2\2EF\3\2\2\2F\21\3\2\2\2GI\5\n"+
		"\6\2HJ\5\20\t\2IH\3\2\2\2JK\3\2\2\2KI\3\2\2\2KL\3\2\2\2LM\3\2\2\2MN\5"+
		"\f\7\2N\23\3\2\2\2\13\26\33 *\64<BEK";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}