// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link prueba12Parser}.
 */
public interface prueba12Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(prueba12Parser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(prueba12Parser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#separadores}.
	 * @param ctx the parse tree
	 */
	void enterSeparadores(prueba12Parser.SeparadoresContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#separadores}.
	 * @param ctx the parse tree
	 */
	void exitSeparadores(prueba12Parser.SeparadoresContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#figuras}.
	 * @param ctx the parse tree
	 */
	void enterFiguras(prueba12Parser.FigurasContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#figuras}.
	 * @param ctx the parse tree
	 */
	void exitFiguras(prueba12Parser.FigurasContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(prueba12Parser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(prueba12Parser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#delinicio}.
	 * @param ctx the parse tree
	 */
	void enterDelinicio(prueba12Parser.DelinicioContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#delinicio}.
	 * @param ctx the parse tree
	 */
	void exitDelinicio(prueba12Parser.DelinicioContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#delfinal}.
	 * @param ctx the parse tree
	 */
	void enterDelfinal(prueba12Parser.DelfinalContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#delfinal}.
	 * @param ctx the parse tree
	 */
	void exitDelfinal(prueba12Parser.DelfinalContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#inicio}.
	 * @param ctx the parse tree
	 */
	void enterInicio(prueba12Parser.InicioContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#inicio}.
	 * @param ctx the parse tree
	 */
	void exitInicio(prueba12Parser.InicioContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#lineaformas}.
	 * @param ctx the parse tree
	 */
	void enterLineaformas(prueba12Parser.LineaformasContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#lineaformas}.
	 * @param ctx the parse tree
	 */
	void exitLineaformas(prueba12Parser.LineaformasContext ctx);
	/**
	 * Enter a parse tree produced by {@link prueba12Parser#formas}.
	 * @param ctx the parse tree
	 */
	void enterFormas(prueba12Parser.FormasContext ctx);
	/**
	 * Exit a parse tree produced by {@link prueba12Parser#formas}.
	 * @param ctx the parse tree
	 */
	void exitFormas(prueba12Parser.FormasContext ctx);
}