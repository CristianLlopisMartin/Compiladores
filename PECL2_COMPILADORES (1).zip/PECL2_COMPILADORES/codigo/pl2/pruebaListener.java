// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link pruebaParser}.
 */
public interface pruebaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link pruebaParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(pruebaParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(pruebaParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#separadores}.
	 * @param ctx the parse tree
	 */
	void enterSeparadores(pruebaParser.SeparadoresContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#separadores}.
	 * @param ctx the parse tree
	 */
	void exitSeparadores(pruebaParser.SeparadoresContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#fecha}.
	 * @param ctx the parse tree
	 */
	void enterFecha(pruebaParser.FechaContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#fecha}.
	 * @param ctx the parse tree
	 */
	void exitFecha(pruebaParser.FechaContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#decimales}.
	 * @param ctx the parse tree
	 */
	void enterDecimales(pruebaParser.DecimalesContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#decimales}.
	 * @param ctx the parse tree
	 */
	void exitDecimales(pruebaParser.DecimalesContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#numeros}.
	 * @param ctx the parse tree
	 */
	void enterNumeros(pruebaParser.NumerosContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#numeros}.
	 * @param ctx the parse tree
	 */
	void exitNumeros(pruebaParser.NumerosContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#string}.
	 * @param ctx the parse tree
	 */
	void enterString(pruebaParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#string}.
	 * @param ctx the parse tree
	 */
	void exitString(pruebaParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link pruebaParser#linea}.
	 * @param ctx the parse tree
	 */
	void enterLinea(pruebaParser.LineaContext ctx);
	/**
	 * Exit a parse tree produced by {@link pruebaParser#linea}.
	 * @param ctx the parse tree
	 */
	void exitLinea(pruebaParser.LineaContext ctx);
}