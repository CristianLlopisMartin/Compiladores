// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gPracticaParser}.
 */
public interface gPracticaParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(gPracticaParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(gPracticaParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#pasos}.
	 * @param ctx the parse tree
	 */
	void enterPasos(gPracticaParser.PasosContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#pasos}.
	 * @param ctx the parse tree
	 */
	void exitPasos(gPracticaParser.PasosContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#accion}.
	 * @param ctx the parse tree
	 */
	void enterAccion(gPracticaParser.AccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#accion}.
	 * @param ctx the parse tree
	 */
	void exitAccion(gPracticaParser.AccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#ingredientes}.
	 * @param ctx the parse tree
	 */
	void enterIngredientes(gPracticaParser.IngredientesContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#ingredientes}.
	 * @param ctx the parse tree
	 */
	void exitIngredientes(gPracticaParser.IngredientesContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#tipo}.
	 * @param ctx the parse tree
	 */
	void enterTipo(gPracticaParser.TipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#tipo}.
	 * @param ctx the parse tree
	 */
	void exitTipo(gPracticaParser.TipoContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#cantidades}.
	 * @param ctx the parse tree
	 */
	void enterCantidades(gPracticaParser.CantidadesContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#cantidades}.
	 * @param ctx the parse tree
	 */
	void exitCantidades(gPracticaParser.CantidadesContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#unidades}.
	 * @param ctx the parse tree
	 */
	void enterUnidades(gPracticaParser.UnidadesContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#unidades}.
	 * @param ctx the parse tree
	 */
	void exitUnidades(gPracticaParser.UnidadesContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#alimento}.
	 * @param ctx the parse tree
	 */
	void enterAlimento(gPracticaParser.AlimentoContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#alimento}.
	 * @param ctx the parse tree
	 */
	void exitAlimento(gPracticaParser.AlimentoContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#auxiliar}.
	 * @param ctx the parse tree
	 */
	void enterAuxiliar(gPracticaParser.AuxiliarContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#auxiliar}.
	 * @param ctx the parse tree
	 */
	void exitAuxiliar(gPracticaParser.AuxiliarContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#receta}.
	 * @param ctx the parse tree
	 */
	void enterReceta(gPracticaParser.RecetaContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#receta}.
	 * @param ctx the parse tree
	 */
	void exitReceta(gPracticaParser.RecetaContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#metodo}.
	 * @param ctx the parse tree
	 */
	void enterMetodo(gPracticaParser.MetodoContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#metodo}.
	 * @param ctx the parse tree
	 */
	void exitMetodo(gPracticaParser.MetodoContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#numero}.
	 * @param ctx the parse tree
	 */
	void enterNumero(gPracticaParser.NumeroContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#numero}.
	 * @param ctx the parse tree
	 */
	void exitNumero(gPracticaParser.NumeroContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#utensilio}.
	 * @param ctx the parse tree
	 */
	void enterUtensilio(gPracticaParser.UtensilioContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#utensilio}.
	 * @param ctx the parse tree
	 */
	void exitUtensilio(gPracticaParser.UtensilioContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#texto}.
	 * @param ctx the parse tree
	 */
	void enterTexto(gPracticaParser.TextoContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#texto}.
	 * @param ctx the parse tree
	 */
	void exitTexto(gPracticaParser.TextoContext ctx);
}