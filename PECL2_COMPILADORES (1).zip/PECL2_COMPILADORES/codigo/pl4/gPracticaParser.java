// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class gPracticaParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LINE=1, LISTA_ABRIR=2, NUMEROPASO=3, VCOCINA=4, UTENSILIO=5, PRODUCTO=6, 
		TEXTO=7, W=8, TEXTOL=9, NUMERO=10, NEWLINE=11, RECETA=12, LISTA_CERRAR=13, 
		INGREDIENTE=14, QUESOS=15, CARNE=16, POLLO=17, VERDURA=18, FRUTA=19, PASTA=20, 
		QUESO=21, LECHE=22, ESPECIAS=23, FRUTOS_SECOS=24, VINO=25, CEREALES=26, 
		UNIDADES=27, AUXILIAR=28, WT=29;
	public static final int
		RULE_prog = 0, RULE_pasos = 1, RULE_accion = 2, RULE_ingredientes = 3, 
		RULE_tipo = 4, RULE_cantidades = 5, RULE_unidades = 6, RULE_alimento = 7, 
		RULE_auxiliar = 8, RULE_receta = 9, RULE_metodo = 10, RULE_numero = 11, 
		RULE_utensilio = 12, RULE_texto = 13;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "pasos", "accion", "ingredientes", "tipo", "cantidades", "unidades", 
			"alimento", "auxiliar", "receta", "metodo", "numero", "utensilio", "texto"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, "'INGREDIENTES'", null, null, null, null, null, "' '", null, 
			null, null, null, "'C\\u00D3MO'", null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, "'de'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "LINE", "LISTA_ABRIR", "NUMEROPASO", "VCOCINA", "UTENSILIO", "PRODUCTO", 
			"TEXTO", "W", "TEXTOL", "NUMERO", "NEWLINE", "RECETA", "LISTA_CERRAR", 
			"INGREDIENTE", "QUESOS", "CARNE", "POLLO", "VERDURA", "FRUTA", "PASTA", 
			"QUESO", "LECHE", "ESPECIAS", "FRUTOS_SECOS", "VINO", "CEREALES", "UNIDADES", 
			"AUXILIAR", "WT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public gPracticaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public List<IngredientesContext> ingredientes() {
			return getRuleContexts(IngredientesContext.class);
		}
		public IngredientesContext ingredientes(int i) {
			return getRuleContext(IngredientesContext.class,i);
		}
		public List<PasosContext> pasos() {
			return getRuleContexts(PasosContext.class);
		}
		public PasosContext pasos(int i) {
			return getRuleContext(PasosContext.class,i);
		}
		public TerminalNode NEWLINE() { return getToken(gPracticaParser.NEWLINE, 0); }
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterProg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitProg(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(32);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==LISTA_ABRIR || _la==NUMEROPASO) {
				{
				setState(30);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case LISTA_ABRIR:
					{
					setState(28);
					ingredientes();
					}
					break;
				case NUMEROPASO:
					{
					setState(29);
					pasos();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(34);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(36);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NEWLINE) {
				{
				setState(35);
				match(NEWLINE);
				}
			}

			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PasosContext extends ParserRuleContext {
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public List<AccionContext> accion() {
			return getRuleContexts(AccionContext.class);
		}
		public AccionContext accion(int i) {
			return getRuleContext(AccionContext.class,i);
		}
		public PasosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pasos; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterPasos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitPasos(this);
		}
	}

	public final PasosContext pasos() throws RecognitionException {
		PasosContext _localctx = new PasosContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_pasos);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(38);
			numero();
			setState(40); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(39);
				accion();
				}
				}
				setState(42); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 49394L) != 0 );
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AccionContext extends ParserRuleContext {
		public TerminalNode LINE() { return getToken(gPracticaParser.LINE, 0); }
		public TextoContext texto() {
			return getRuleContext(TextoContext.class,0);
		}
		public MetodoContext metodo() {
			return getRuleContext(MetodoContext.class,0);
		}
		public AlimentoContext alimento() {
			return getRuleContext(AlimentoContext.class,0);
		}
		public UtensilioContext utensilio() {
			return getRuleContext(UtensilioContext.class,0);
		}
		public AccionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_accion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterAccion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitAccion(this);
		}
	}

	public final AccionContext accion() throws RecognitionException {
		AccionContext _localctx = new AccionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_accion);
		try {
			setState(49);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LINE:
				enterOuterAlt(_localctx, 1);
				{
				setState(44);
				match(LINE);
				}
				break;
			case TEXTO:
				enterOuterAlt(_localctx, 2);
				{
				setState(45);
				texto();
				}
				break;
			case VCOCINA:
				enterOuterAlt(_localctx, 3);
				{
				setState(46);
				metodo();
				}
				break;
			case PRODUCTO:
			case INGREDIENTE:
			case QUESOS:
				enterOuterAlt(_localctx, 4);
				{
				setState(47);
				alimento();
				}
				break;
			case UTENSILIO:
				enterOuterAlt(_localctx, 5);
				{
				setState(48);
				utensilio();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IngredientesContext extends ParserRuleContext {
		public TerminalNode LISTA_ABRIR() { return getToken(gPracticaParser.LISTA_ABRIR, 0); }
		public TerminalNode LISTA_CERRAR() { return getToken(gPracticaParser.LISTA_CERRAR, 0); }
		public List<RecetaContext> receta() {
			return getRuleContexts(RecetaContext.class);
		}
		public RecetaContext receta(int i) {
			return getRuleContext(RecetaContext.class,i);
		}
		public List<TipoContext> tipo() {
			return getRuleContexts(TipoContext.class);
		}
		public TipoContext tipo(int i) {
			return getRuleContext(TipoContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(gPracticaParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(gPracticaParser.NEWLINE, i);
		}
		public IngredientesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ingredientes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterIngredientes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitIngredientes(this);
		}
	}

	public final IngredientesContext ingredientes() throws RecognitionException {
		IngredientesContext _localctx = new IngredientesContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_ingredientes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51);
			match(LISTA_ABRIR);
			setState(57);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 402709568L) != 0) {
				{
				setState(55);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case RECETA:
					{
					setState(52);
					receta();
					}
					break;
				case PRODUCTO:
				case NUMERO:
				case INGREDIENTE:
				case QUESOS:
				case UNIDADES:
				case AUXILIAR:
					{
					setState(53);
					tipo();
					}
					break;
				case NEWLINE:
					{
					setState(54);
					match(NEWLINE);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(59);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(60);
			match(LISTA_CERRAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TipoContext extends ParserRuleContext {
		public AlimentoContext alimento() {
			return getRuleContext(AlimentoContext.class,0);
		}
		public CantidadesContext cantidades() {
			return getRuleContext(CantidadesContext.class,0);
		}
		public UnidadesContext unidades() {
			return getRuleContext(UnidadesContext.class,0);
		}
		public AuxiliarContext auxiliar() {
			return getRuleContext(AuxiliarContext.class,0);
		}
		public TipoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterTipo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitTipo(this);
		}
	}

	public final TipoContext tipo() throws RecognitionException {
		TipoContext _localctx = new TipoContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_tipo);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(63);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NUMERO) {
				{
				setState(62);
				cantidades();
				}
			}

			setState(66);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==UNIDADES) {
				{
				setState(65);
				unidades();
				}
			}

			setState(69);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AUXILIAR) {
				{
				setState(68);
				auxiliar();
				}
			}

			setState(71);
			alimento();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CantidadesContext extends ParserRuleContext {
		public TerminalNode NUMERO() { return getToken(gPracticaParser.NUMERO, 0); }
		public CantidadesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cantidades; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterCantidades(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitCantidades(this);
		}
	}

	public final CantidadesContext cantidades() throws RecognitionException {
		CantidadesContext _localctx = new CantidadesContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_cantidades);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			match(NUMERO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UnidadesContext extends ParserRuleContext {
		public TerminalNode UNIDADES() { return getToken(gPracticaParser.UNIDADES, 0); }
		public UnidadesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unidades; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterUnidades(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitUnidades(this);
		}
	}

	public final UnidadesContext unidades() throws RecognitionException {
		UnidadesContext _localctx = new UnidadesContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_unidades);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(75);
			match(UNIDADES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlimentoContext extends ParserRuleContext {
		public TerminalNode INGREDIENTE() { return getToken(gPracticaParser.INGREDIENTE, 0); }
		public TerminalNode PRODUCTO() { return getToken(gPracticaParser.PRODUCTO, 0); }
		public TerminalNode QUESOS() { return getToken(gPracticaParser.QUESOS, 0); }
		public AlimentoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alimento; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterAlimento(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitAlimento(this);
		}
	}

	public final AlimentoContext alimento() throws RecognitionException {
		AlimentoContext _localctx = new AlimentoContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_alimento);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(77);
			_la = _input.LA(1);
			if ( !(((_la) & ~0x3f) == 0 && ((1L << _la) & 49216L) != 0) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AuxiliarContext extends ParserRuleContext {
		public TerminalNode AUXILIAR() { return getToken(gPracticaParser.AUXILIAR, 0); }
		public AuxiliarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_auxiliar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterAuxiliar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitAuxiliar(this);
		}
	}

	public final AuxiliarContext auxiliar() throws RecognitionException {
		AuxiliarContext _localctx = new AuxiliarContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_auxiliar);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			match(AUXILIAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RecetaContext extends ParserRuleContext {
		public TerminalNode RECETA() { return getToken(gPracticaParser.RECETA, 0); }
		public RecetaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_receta; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterReceta(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitReceta(this);
		}
	}

	public final RecetaContext receta() throws RecognitionException {
		RecetaContext _localctx = new RecetaContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_receta);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(81);
			match(RECETA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MetodoContext extends ParserRuleContext {
		public TerminalNode VCOCINA() { return getToken(gPracticaParser.VCOCINA, 0); }
		public MetodoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_metodo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterMetodo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitMetodo(this);
		}
	}

	public final MetodoContext metodo() throws RecognitionException {
		MetodoContext _localctx = new MetodoContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_metodo);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(83);
			match(VCOCINA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumeroContext extends ParserRuleContext {
		public TerminalNode NUMEROPASO() { return getToken(gPracticaParser.NUMEROPASO, 0); }
		public NumeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numero; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterNumero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitNumero(this);
		}
	}

	public final NumeroContext numero() throws RecognitionException {
		NumeroContext _localctx = new NumeroContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_numero);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(85);
			match(NUMEROPASO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UtensilioContext extends ParserRuleContext {
		public TerminalNode UTENSILIO() { return getToken(gPracticaParser.UTENSILIO, 0); }
		public UtensilioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_utensilio; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterUtensilio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitUtensilio(this);
		}
	}

	public final UtensilioContext utensilio() throws RecognitionException {
		UtensilioContext _localctx = new UtensilioContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_utensilio);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(87);
			match(UTENSILIO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TextoContext extends ParserRuleContext {
		public TerminalNode TEXTO() { return getToken(gPracticaParser.TEXTO, 0); }
		public TextoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_texto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterTexto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitTexto(this);
		}
	}

	public final TextoContext texto() throws RecognitionException {
		TextoContext _localctx = new TextoContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_texto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			match(TEXTO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u001d\\\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0001\u0000\u0001\u0000\u0005\u0000\u001f\b"+
		"\u0000\n\u0000\f\u0000\"\t\u0000\u0001\u0000\u0003\u0000%\b\u0000\u0001"+
		"\u0001\u0001\u0001\u0004\u0001)\b\u0001\u000b\u0001\f\u0001*\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u00022\b\u0002"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0005\u00038\b\u0003"+
		"\n\u0003\f\u0003;\t\u0003\u0001\u0003\u0001\u0003\u0001\u0004\u0003\u0004"+
		"@\b\u0004\u0001\u0004\u0003\u0004C\b\u0004\u0001\u0004\u0003\u0004F\b"+
		"\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0006\u0001"+
		"\u0006\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001\t\u0001\t\u0001\n"+
		"\u0001\n\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001\r\u0001\r\u0001"+
		"\r\u0000\u0000\u000e\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014"+
		"\u0016\u0018\u001a\u0000\u0001\u0002\u0000\u0006\u0006\u000e\u000f[\u0000"+
		" \u0001\u0000\u0000\u0000\u0002&\u0001\u0000\u0000\u0000\u00041\u0001"+
		"\u0000\u0000\u0000\u00063\u0001\u0000\u0000\u0000\b?\u0001\u0000\u0000"+
		"\u0000\nI\u0001\u0000\u0000\u0000\fK\u0001\u0000\u0000\u0000\u000eM\u0001"+
		"\u0000\u0000\u0000\u0010O\u0001\u0000\u0000\u0000\u0012Q\u0001\u0000\u0000"+
		"\u0000\u0014S\u0001\u0000\u0000\u0000\u0016U\u0001\u0000\u0000\u0000\u0018"+
		"W\u0001\u0000\u0000\u0000\u001aY\u0001\u0000\u0000\u0000\u001c\u001f\u0003"+
		"\u0006\u0003\u0000\u001d\u001f\u0003\u0002\u0001\u0000\u001e\u001c\u0001"+
		"\u0000\u0000\u0000\u001e\u001d\u0001\u0000\u0000\u0000\u001f\"\u0001\u0000"+
		"\u0000\u0000 \u001e\u0001\u0000\u0000\u0000 !\u0001\u0000\u0000\u0000"+
		"!$\u0001\u0000\u0000\u0000\" \u0001\u0000\u0000\u0000#%\u0005\u000b\u0000"+
		"\u0000$#\u0001\u0000\u0000\u0000$%\u0001\u0000\u0000\u0000%\u0001\u0001"+
		"\u0000\u0000\u0000&(\u0003\u0016\u000b\u0000\')\u0003\u0004\u0002\u0000"+
		"(\'\u0001\u0000\u0000\u0000)*\u0001\u0000\u0000\u0000*(\u0001\u0000\u0000"+
		"\u0000*+\u0001\u0000\u0000\u0000+\u0003\u0001\u0000\u0000\u0000,2\u0005"+
		"\u0001\u0000\u0000-2\u0003\u001a\r\u0000.2\u0003\u0014\n\u0000/2\u0003"+
		"\u000e\u0007\u000002\u0003\u0018\f\u00001,\u0001\u0000\u0000\u00001-\u0001"+
		"\u0000\u0000\u00001.\u0001\u0000\u0000\u00001/\u0001\u0000\u0000\u0000"+
		"10\u0001\u0000\u0000\u00002\u0005\u0001\u0000\u0000\u000039\u0005\u0002"+
		"\u0000\u000048\u0003\u0012\t\u000058\u0003\b\u0004\u000068\u0005\u000b"+
		"\u0000\u000074\u0001\u0000\u0000\u000075\u0001\u0000\u0000\u000076\u0001"+
		"\u0000\u0000\u00008;\u0001\u0000\u0000\u000097\u0001\u0000\u0000\u0000"+
		"9:\u0001\u0000\u0000\u0000:<\u0001\u0000\u0000\u0000;9\u0001\u0000\u0000"+
		"\u0000<=\u0005\r\u0000\u0000=\u0007\u0001\u0000\u0000\u0000>@\u0003\n"+
		"\u0005\u0000?>\u0001\u0000\u0000\u0000?@\u0001\u0000\u0000\u0000@B\u0001"+
		"\u0000\u0000\u0000AC\u0003\f\u0006\u0000BA\u0001\u0000\u0000\u0000BC\u0001"+
		"\u0000\u0000\u0000CE\u0001\u0000\u0000\u0000DF\u0003\u0010\b\u0000ED\u0001"+
		"\u0000\u0000\u0000EF\u0001\u0000\u0000\u0000FG\u0001\u0000\u0000\u0000"+
		"GH\u0003\u000e\u0007\u0000H\t\u0001\u0000\u0000\u0000IJ\u0005\n\u0000"+
		"\u0000J\u000b\u0001\u0000\u0000\u0000KL\u0005\u001b\u0000\u0000L\r\u0001"+
		"\u0000\u0000\u0000MN\u0007\u0000\u0000\u0000N\u000f\u0001\u0000\u0000"+
		"\u0000OP\u0005\u001c\u0000\u0000P\u0011\u0001\u0000\u0000\u0000QR\u0005"+
		"\f\u0000\u0000R\u0013\u0001\u0000\u0000\u0000ST\u0005\u0004\u0000\u0000"+
		"T\u0015\u0001\u0000\u0000\u0000UV\u0005\u0003\u0000\u0000V\u0017\u0001"+
		"\u0000\u0000\u0000WX\u0005\u0005\u0000\u0000X\u0019\u0001\u0000\u0000"+
		"\u0000YZ\u0005\u0007\u0000\u0000Z\u001b\u0001\u0000\u0000\u0000\n\u001e"+
		" $*179?BE";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}