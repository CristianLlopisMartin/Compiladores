import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.FileInputStream;
import java.io.InputStream;

public class Analizador {
    public static void main(String[] args) throws Exception{

        String inputFile= null;
        if (args.length>0) inputFile=args[0];

        InputStream is = System.in;
        if (inputFile!=null) is = new FileInputStream(inputFile);

        CharStream input = CharStreams.fromFileName(inputFile);

        gPracticaLexer lexer = new gPracticaLexer(input);

        CommonTokenStream tokens = new CommonTokenStream(lexer);

        gPracticaParser parser = new gPracticaParser(tokens);

        ParseTree tree = parser.prog();

        System.out.println(tree.toStringTree(parser));

        //ParseTreeWalker walker = new ºParseTreeWalker();

        //AnalizadorListener escuchador = new AnalizadorListener();

        //walker.walk(escuchador,tree);
    }
}