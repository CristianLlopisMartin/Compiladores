// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class gPracticaParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		MOSTRAR=1, NEWLINE=2, IGUAL=3, COMPARADORES=4, CONDICIONAL=5, DECISION=6, 
		OPERACIONES1=7, OPERACIONES2=8, INT=9, FLOAT=10, FINAL=11, ASIGNAR=12, 
		FIN=13, VARIABLE=14, COMENTARIOlinea=15, COMENTARIOVlineas=16, WS=17, 
		FINAL_COMENTARIO=18, LETRA=19, COMENTARIO_CERRAR=20, LETRACOMEN=21;
	public static final int
		RULE_prog = 0, RULE_expr = 1, RULE_variable = 2, RULE_numero = 3, RULE_lfinal = 4, 
		RULE_pantalla = 5, RULE_asignacion = 6, RULE_comentario = 7, RULE_textos = 8, 
		RULE_textos2 = 9, RULE_condicion = 10, RULE_ifCondicion = 11;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "expr", "variable", "numero", "lfinal", "pantalla", "asignacion", 
			"comentario", "textos", "textos2", "condicion", "ifCondicion"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, "'#'", "'/*'", null, null, null, "'*/'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "MOSTRAR", "NEWLINE", "IGUAL", "COMPARADORES", "CONDICIONAL", "DECISION", 
			"OPERACIONES1", "OPERACIONES2", "INT", "FLOAT", "FINAL", "ASIGNAR", "FIN", 
			"VARIABLE", "COMENTARIOlinea", "COMENTARIOVlineas", "WS", "FINAL_COMENTARIO", 
			"LETRA", "COMENTARIO_CERRAR", "LETRACOMEN"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public gPracticaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public List<IfCondicionContext> ifCondicion() {
			return getRuleContexts(IfCondicionContext.class);
		}
		public IfCondicionContext ifCondicion(int i) {
			return getRuleContext(IfCondicionContext.class,i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(gPracticaParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(gPracticaParser.NEWLINE, i);
		}
		public List<PantallaContext> pantalla() {
			return getRuleContexts(PantallaContext.class);
		}
		public PantallaContext pantalla(int i) {
			return getRuleContext(PantallaContext.class,i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterProg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitProg(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(30); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					setState(30);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
					case 1:
						{
						setState(24);
						expr(0);
						}
						break;
					case 2:
						{
						setState(25);
						asignacion();
						}
						break;
					case 3:
						{
						setState(26);
						ifCondicion();
						}
						break;
					case 4:
						{
						setState(27);
						comentario();
						}
						break;
					case 5:
						{
						setState(28);
						match(NEWLINE);
						}
						break;
					case 6:
						{
						setState(29);
						pantalla();
						}
						break;
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(32); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,1,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(35);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NEWLINE) {
				{
				setState(34);
				match(NEWLINE);
				}
			}

			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode OPERACIONES1() { return getToken(gPracticaParser.OPERACIONES1, 0); }
		public TerminalNode OPERACIONES2() { return getToken(gPracticaParser.OPERACIONES2, 0); }
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitExpr(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 2;
		enterRecursionRule(_localctx, 2, RULE_expr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(40);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
			case FLOAT:
				{
				setState(38);
				numero();
				}
				break;
			case VARIABLE:
				{
				setState(39);
				variable();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(50);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(48);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
					case 1:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(42);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(43);
						match(OPERACIONES1);
						setState(44);
						expr(5);
						}
						break;
					case 2:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(45);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(46);
						match(OPERACIONES2);
						setState(47);
						expr(4);
						}
						break;
					}
					} 
				}
				setState(52);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VariableContext extends ParserRuleContext {
		public TerminalNode VARIABLE() { return getToken(gPracticaParser.VARIABLE, 0); }
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitVariable(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(53);
			match(VARIABLE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumeroContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(gPracticaParser.FLOAT, 0); }
		public NumeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numero; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterNumero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitNumero(this);
		}
	}

	public final NumeroContext numero() throws RecognitionException {
		NumeroContext _localctx = new NumeroContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_numero);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			_la = _input.LA(1);
			if ( !(_la==INT || _la==FLOAT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LfinalContext extends ParserRuleContext {
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public LfinalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lfinal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterLfinal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitLfinal(this);
		}
	}

	public final LfinalContext lfinal() throws RecognitionException {
		LfinalContext _localctx = new LfinalContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_lfinal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(57);
			match(FINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PantallaContext extends ParserRuleContext {
		public TerminalNode MOSTRAR() { return getToken(gPracticaParser.MOSTRAR, 0); }
		public LfinalContext lfinal() {
			return getRuleContext(LfinalContext.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public PantallaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pantalla; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterPantalla(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitPantalla(this);
		}
	}

	public final PantallaContext pantalla() throws RecognitionException {
		PantallaContext _localctx = new PantallaContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_pantalla);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(59);
			match(MOSTRAR);
			setState(61); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(60);
				expr(0);
				}
				}
				setState(63); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 17920L) != 0 );
			setState(65);
			lfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AsignacionContext extends ParserRuleContext {
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TerminalNode IGUAL() { return getToken(gPracticaParser.IGUAL, 0); }
		public LfinalContext lfinal() {
			return getRuleContext(LfinalContext.class,0);
		}
		public TerminalNode ASIGNAR() { return getToken(gPracticaParser.ASIGNAR, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public AsignacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterAsignacion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitAsignacion(this);
		}
	}

	public final AsignacionContext asignacion() throws RecognitionException {
		AsignacionContext _localctx = new AsignacionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_asignacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASIGNAR) {
				{
				setState(67);
				match(ASIGNAR);
				}
			}

			setState(70);
			variable();
			setState(71);
			match(IGUAL);
			setState(73); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(72);
				expr(0);
				}
				}
				setState(75); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 17920L) != 0 );
			setState(77);
			lfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComentarioContext extends ParserRuleContext {
		public TerminalNode COMENTARIOVlineas() { return getToken(gPracticaParser.COMENTARIOVlineas, 0); }
		public TerminalNode COMENTARIO_CERRAR() { return getToken(gPracticaParser.COMENTARIO_CERRAR, 0); }
		public List<Textos2Context> textos2() {
			return getRuleContexts(Textos2Context.class);
		}
		public Textos2Context textos2(int i) {
			return getRuleContext(Textos2Context.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(gPracticaParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(gPracticaParser.NEWLINE, i);
		}
		public TerminalNode COMENTARIOlinea() { return getToken(gPracticaParser.COMENTARIOlinea, 0); }
		public TerminalNode FINAL_COMENTARIO() { return getToken(gPracticaParser.FINAL_COMENTARIO, 0); }
		public List<TextosContext> textos() {
			return getRuleContexts(TextosContext.class);
		}
		public TextosContext textos(int i) {
			return getRuleContext(TextosContext.class,i);
		}
		public ComentarioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comentario; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterComentario(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitComentario(this);
		}
	}

	public final ComentarioContext comentario() throws RecognitionException {
		ComentarioContext _localctx = new ComentarioContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_comentario);
		int _la;
		try {
			setState(96);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COMENTARIOVlineas:
				enterOuterAlt(_localctx, 1);
				{
				setState(79);
				match(COMENTARIOVlineas);
				setState(84);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE || _la==LETRACOMEN) {
					{
					setState(82);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case LETRACOMEN:
						{
						setState(80);
						textos2();
						}
						break;
					case NEWLINE:
						{
						setState(81);
						match(NEWLINE);
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					setState(86);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(87);
				match(COMENTARIO_CERRAR);
				}
				break;
			case COMENTARIOlinea:
				enterOuterAlt(_localctx, 2);
				{
				setState(88);
				match(COMENTARIOlinea);
				setState(92);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==LETRA) {
					{
					{
					setState(89);
					textos();
					}
					}
					setState(94);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(95);
				match(FINAL_COMENTARIO);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TextosContext extends ParserRuleContext {
		public List<TerminalNode> LETRA() { return getTokens(gPracticaParser.LETRA); }
		public TerminalNode LETRA(int i) {
			return getToken(gPracticaParser.LETRA, i);
		}
		public TextosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textos; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterTextos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitTextos(this);
		}
	}

	public final TextosContext textos() throws RecognitionException {
		TextosContext _localctx = new TextosContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_textos);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(99); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(98);
					match(LETRA);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(101); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Textos2Context extends ParserRuleContext {
		public List<TerminalNode> LETRACOMEN() { return getTokens(gPracticaParser.LETRACOMEN); }
		public TerminalNode LETRACOMEN(int i) {
			return getToken(gPracticaParser.LETRACOMEN, i);
		}
		public Textos2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textos2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterTextos2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitTextos2(this);
		}
	}

	public final Textos2Context textos2() throws RecognitionException {
		Textos2Context _localctx = new Textos2Context(_ctx, getState());
		enterRule(_localctx, 18, RULE_textos2);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(104); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(103);
					match(LETRACOMEN);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(106); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CondicionContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode COMPARADORES() { return getToken(gPracticaParser.COMPARADORES, 0); }
		public TerminalNode CONDICIONAL() { return getToken(gPracticaParser.CONDICIONAL, 0); }
		public TerminalNode DECISION() { return getToken(gPracticaParser.DECISION, 0); }
		public AsignacionContext asignacion() {
			return getRuleContext(AsignacionContext.class,0);
		}
		public TerminalNode FIN() { return getToken(gPracticaParser.FIN, 0); }
		public CondicionContext condicion() {
			return getRuleContext(CondicionContext.class,0);
		}
		public TerminalNode NEWLINE() { return getToken(gPracticaParser.NEWLINE, 0); }
		public CondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterCondicion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitCondicion(this);
		}
	}

	public final CondicionContext condicion() throws RecognitionException {
		return condicion(0);
	}

	private CondicionContext condicion(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		CondicionContext _localctx = new CondicionContext(_ctx, _parentState);
		CondicionContext _prevctx = _localctx;
		int _startState = 20;
		enterRecursionRule(_localctx, 20, RULE_condicion, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				{
				setState(109);
				expr(0);
				setState(110);
				match(COMPARADORES);
				setState(111);
				expr(0);
				setState(112);
				match(CONDICIONAL);
				}
				break;
			case 2:
				{
				setState(114);
				match(DECISION);
				}
				break;
			case 3:
				{
				setState(115);
				asignacion();
				setState(117);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
				case 1:
					{
					setState(116);
					match(FIN);
					}
					break;
				}
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(125);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CondicionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_condicion);
					setState(121);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(122);
					match(NEWLINE);
					}
					} 
				}
				setState(127);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfCondicionContext extends ParserRuleContext {
		public List<CondicionContext> condicion() {
			return getRuleContexts(CondicionContext.class);
		}
		public CondicionContext condicion(int i) {
			return getRuleContext(CondicionContext.class,i);
		}
		public IfCondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifCondicion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).enterIfCondicion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof gPracticaParserListener ) ((gPracticaParserListener)listener).exitIfCondicion(this);
		}
	}

	public final IfCondicionContext ifCondicion() throws RecognitionException {
		IfCondicionContext _localctx = new IfCondicionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_ifCondicion);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			condicion(0);
			setState(132);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(129);
					condicion(0);
					}
					} 
				}
				setState(134);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 1:
			return expr_sempred((ExprContext)_localctx, predIndex);
		case 10:
			return condicion_sempred((CondicionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 4);
		case 1:
			return precpred(_ctx, 3);
		}
		return true;
	}
	private boolean condicion_sempred(CondicionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 1);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0015\u0088\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000"+
		"\u0004\u0000\u001f\b\u0000\u000b\u0000\f\u0000 \u0001\u0000\u0003\u0000"+
		"$\b\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u0001)\b\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0005"+
		"\u00011\b\u0001\n\u0001\f\u00014\t\u0001\u0001\u0002\u0001\u0002\u0001"+
		"\u0003\u0001\u0003\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0004"+
		"\u0005>\b\u0005\u000b\u0005\f\u0005?\u0001\u0005\u0001\u0005\u0001\u0006"+
		"\u0003\u0006E\b\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0004\u0006"+
		"J\b\u0006\u000b\u0006\f\u0006K\u0001\u0006\u0001\u0006\u0001\u0007\u0001"+
		"\u0007\u0001\u0007\u0005\u0007S\b\u0007\n\u0007\f\u0007V\t\u0007\u0001"+
		"\u0007\u0001\u0007\u0001\u0007\u0005\u0007[\b\u0007\n\u0007\f\u0007^\t"+
		"\u0007\u0001\u0007\u0003\u0007a\b\u0007\u0001\b\u0004\bd\b\b\u000b\b\f"+
		"\be\u0001\t\u0004\ti\b\t\u000b\t\f\tj\u0001\n\u0001\n\u0001\n\u0001\n"+
		"\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0003\nv\b\n\u0003\nx\b\n\u0001"+
		"\n\u0001\n\u0005\n|\b\n\n\n\f\n\u007f\t\n\u0001\u000b\u0001\u000b\u0005"+
		"\u000b\u0083\b\u000b\n\u000b\f\u000b\u0086\t\u000b\u0001\u000b\u0000\u0002"+
		"\u0002\u0014\f\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016"+
		"\u0000\u0001\u0001\u0000\t\n\u0093\u0000\u001e\u0001\u0000\u0000\u0000"+
		"\u0002(\u0001\u0000\u0000\u0000\u00045\u0001\u0000\u0000\u0000\u00067"+
		"\u0001\u0000\u0000\u0000\b9\u0001\u0000\u0000\u0000\n;\u0001\u0000\u0000"+
		"\u0000\fD\u0001\u0000\u0000\u0000\u000e`\u0001\u0000\u0000\u0000\u0010"+
		"c\u0001\u0000\u0000\u0000\u0012h\u0001\u0000\u0000\u0000\u0014w\u0001"+
		"\u0000\u0000\u0000\u0016\u0080\u0001\u0000\u0000\u0000\u0018\u001f\u0003"+
		"\u0002\u0001\u0000\u0019\u001f\u0003\f\u0006\u0000\u001a\u001f\u0003\u0016"+
		"\u000b\u0000\u001b\u001f\u0003\u000e\u0007\u0000\u001c\u001f\u0005\u0002"+
		"\u0000\u0000\u001d\u001f\u0003\n\u0005\u0000\u001e\u0018\u0001\u0000\u0000"+
		"\u0000\u001e\u0019\u0001\u0000\u0000\u0000\u001e\u001a\u0001\u0000\u0000"+
		"\u0000\u001e\u001b\u0001\u0000\u0000\u0000\u001e\u001c\u0001\u0000\u0000"+
		"\u0000\u001e\u001d\u0001\u0000\u0000\u0000\u001f \u0001\u0000\u0000\u0000"+
		" \u001e\u0001\u0000\u0000\u0000 !\u0001\u0000\u0000\u0000!#\u0001\u0000"+
		"\u0000\u0000\"$\u0005\u0002\u0000\u0000#\"\u0001\u0000\u0000\u0000#$\u0001"+
		"\u0000\u0000\u0000$\u0001\u0001\u0000\u0000\u0000%&\u0006\u0001\uffff"+
		"\uffff\u0000&)\u0003\u0006\u0003\u0000\')\u0003\u0004\u0002\u0000(%\u0001"+
		"\u0000\u0000\u0000(\'\u0001\u0000\u0000\u0000)2\u0001\u0000\u0000\u0000"+
		"*+\n\u0004\u0000\u0000+,\u0005\u0007\u0000\u0000,1\u0003\u0002\u0001\u0005"+
		"-.\n\u0003\u0000\u0000./\u0005\b\u0000\u0000/1\u0003\u0002\u0001\u0004"+
		"0*\u0001\u0000\u0000\u00000-\u0001\u0000\u0000\u000014\u0001\u0000\u0000"+
		"\u000020\u0001\u0000\u0000\u000023\u0001\u0000\u0000\u00003\u0003\u0001"+
		"\u0000\u0000\u000042\u0001\u0000\u0000\u000056\u0005\u000e\u0000\u0000"+
		"6\u0005\u0001\u0000\u0000\u000078\u0007\u0000\u0000\u00008\u0007\u0001"+
		"\u0000\u0000\u00009:\u0005\u000b\u0000\u0000:\t\u0001\u0000\u0000\u0000"+
		";=\u0005\u0001\u0000\u0000<>\u0003\u0002\u0001\u0000=<\u0001\u0000\u0000"+
		"\u0000>?\u0001\u0000\u0000\u0000?=\u0001\u0000\u0000\u0000?@\u0001\u0000"+
		"\u0000\u0000@A\u0001\u0000\u0000\u0000AB\u0003\b\u0004\u0000B\u000b\u0001"+
		"\u0000\u0000\u0000CE\u0005\f\u0000\u0000DC\u0001\u0000\u0000\u0000DE\u0001"+
		"\u0000\u0000\u0000EF\u0001\u0000\u0000\u0000FG\u0003\u0004\u0002\u0000"+
		"GI\u0005\u0003\u0000\u0000HJ\u0003\u0002\u0001\u0000IH\u0001\u0000\u0000"+
		"\u0000JK\u0001\u0000\u0000\u0000KI\u0001\u0000\u0000\u0000KL\u0001\u0000"+
		"\u0000\u0000LM\u0001\u0000\u0000\u0000MN\u0003\b\u0004\u0000N\r\u0001"+
		"\u0000\u0000\u0000OT\u0005\u0010\u0000\u0000PS\u0003\u0012\t\u0000QS\u0005"+
		"\u0002\u0000\u0000RP\u0001\u0000\u0000\u0000RQ\u0001\u0000\u0000\u0000"+
		"SV\u0001\u0000\u0000\u0000TR\u0001\u0000\u0000\u0000TU\u0001\u0000\u0000"+
		"\u0000UW\u0001\u0000\u0000\u0000VT\u0001\u0000\u0000\u0000Wa\u0005\u0014"+
		"\u0000\u0000X\\\u0005\u000f\u0000\u0000Y[\u0003\u0010\b\u0000ZY\u0001"+
		"\u0000\u0000\u0000[^\u0001\u0000\u0000\u0000\\Z\u0001\u0000\u0000\u0000"+
		"\\]\u0001\u0000\u0000\u0000]_\u0001\u0000\u0000\u0000^\\\u0001\u0000\u0000"+
		"\u0000_a\u0005\u0012\u0000\u0000`O\u0001\u0000\u0000\u0000`X\u0001\u0000"+
		"\u0000\u0000a\u000f\u0001\u0000\u0000\u0000bd\u0005\u0013\u0000\u0000"+
		"cb\u0001\u0000\u0000\u0000de\u0001\u0000\u0000\u0000ec\u0001\u0000\u0000"+
		"\u0000ef\u0001\u0000\u0000\u0000f\u0011\u0001\u0000\u0000\u0000gi\u0005"+
		"\u0015\u0000\u0000hg\u0001\u0000\u0000\u0000ij\u0001\u0000\u0000\u0000"+
		"jh\u0001\u0000\u0000\u0000jk\u0001\u0000\u0000\u0000k\u0013\u0001\u0000"+
		"\u0000\u0000lm\u0006\n\uffff\uffff\u0000mn\u0003\u0002\u0001\u0000no\u0005"+
		"\u0004\u0000\u0000op\u0003\u0002\u0001\u0000pq\u0005\u0005\u0000\u0000"+
		"qx\u0001\u0000\u0000\u0000rx\u0005\u0006\u0000\u0000su\u0003\f\u0006\u0000"+
		"tv\u0005\r\u0000\u0000ut\u0001\u0000\u0000\u0000uv\u0001\u0000\u0000\u0000"+
		"vx\u0001\u0000\u0000\u0000wl\u0001\u0000\u0000\u0000wr\u0001\u0000\u0000"+
		"\u0000ws\u0001\u0000\u0000\u0000x}\u0001\u0000\u0000\u0000yz\n\u0001\u0000"+
		"\u0000z|\u0005\u0002\u0000\u0000{y\u0001\u0000\u0000\u0000|\u007f\u0001"+
		"\u0000\u0000\u0000}{\u0001\u0000\u0000\u0000}~\u0001\u0000\u0000\u0000"+
		"~\u0015\u0001\u0000\u0000\u0000\u007f}\u0001\u0000\u0000\u0000\u0080\u0084"+
		"\u0003\u0014\n\u0000\u0081\u0083\u0003\u0014\n\u0000\u0082\u0081\u0001"+
		"\u0000\u0000\u0000\u0083\u0086\u0001\u0000\u0000\u0000\u0084\u0082\u0001"+
		"\u0000\u0000\u0000\u0084\u0085\u0001\u0000\u0000\u0000\u0085\u0017\u0001"+
		"\u0000\u0000\u0000\u0086\u0084\u0001\u0000\u0000\u0000\u0013\u001e #("+
		"02?DKRT\\`ejuw}\u0084";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}