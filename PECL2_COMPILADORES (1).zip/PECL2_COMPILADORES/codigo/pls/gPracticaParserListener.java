// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gPracticaParser}.
 */
public interface gPracticaParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(gPracticaParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(gPracticaParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(gPracticaParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(gPracticaParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#variable}.
	 * @param ctx the parse tree
	 */
	void enterVariable(gPracticaParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#variable}.
	 * @param ctx the parse tree
	 */
	void exitVariable(gPracticaParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#numero}.
	 * @param ctx the parse tree
	 */
	void enterNumero(gPracticaParser.NumeroContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#numero}.
	 * @param ctx the parse tree
	 */
	void exitNumero(gPracticaParser.NumeroContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#lfinal}.
	 * @param ctx the parse tree
	 */
	void enterLfinal(gPracticaParser.LfinalContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#lfinal}.
	 * @param ctx the parse tree
	 */
	void exitLfinal(gPracticaParser.LfinalContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#pantalla}.
	 * @param ctx the parse tree
	 */
	void enterPantalla(gPracticaParser.PantallaContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#pantalla}.
	 * @param ctx the parse tree
	 */
	void exitPantalla(gPracticaParser.PantallaContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion(gPracticaParser.AsignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion(gPracticaParser.AsignacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#comentario}.
	 * @param ctx the parse tree
	 */
	void enterComentario(gPracticaParser.ComentarioContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#comentario}.
	 * @param ctx the parse tree
	 */
	void exitComentario(gPracticaParser.ComentarioContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#textos}.
	 * @param ctx the parse tree
	 */
	void enterTextos(gPracticaParser.TextosContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#textos}.
	 * @param ctx the parse tree
	 */
	void exitTextos(gPracticaParser.TextosContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#textos2}.
	 * @param ctx the parse tree
	 */
	void enterTextos2(gPracticaParser.Textos2Context ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#textos2}.
	 * @param ctx the parse tree
	 */
	void exitTextos2(gPracticaParser.Textos2Context ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#condicion}.
	 * @param ctx the parse tree
	 */
	void enterCondicion(gPracticaParser.CondicionContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#condicion}.
	 * @param ctx the parse tree
	 */
	void exitCondicion(gPracticaParser.CondicionContext ctx);
	/**
	 * Enter a parse tree produced by {@link gPracticaParser#ifCondicion}.
	 * @param ctx the parse tree
	 */
	void enterIfCondicion(gPracticaParser.IfCondicionContext ctx);
	/**
	 * Exit a parse tree produced by {@link gPracticaParser#ifCondicion}.
	 * @param ctx the parse tree
	 */
	void exitIfCondicion(gPracticaParser.IfCondicionContext ctx);
}