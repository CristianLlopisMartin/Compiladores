import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.FileInputStream;
import java.io.InputStream;

public class AnalizadorListener extends gPracticaParserListener{
    @Override

    public void visitarTerminal(Terminal node){
        System.out.println(node);
    }


}