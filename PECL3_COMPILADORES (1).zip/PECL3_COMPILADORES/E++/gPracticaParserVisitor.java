// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link gPracticaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface gPracticaParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(gPracticaParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#pantalla}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPantalla(gPracticaParser.PantallaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Asignar}
	 * labeled alternative in {@link gPracticaParser#asignacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsignar(gPracticaParser.AsignarContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#comentario}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComentario(gPracticaParser.ComentarioContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#textos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTextos(gPracticaParser.TextosContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#textos2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTextos2(gPracticaParser.Textos2Context ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#condicion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondicion(gPracticaParser.CondicionContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#ifCondicion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfCondicion(gPracticaParser.IfCondicionContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#loopCondicion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoopCondicion(gPracticaParser.LoopCondicionContext ctx);
	/**
	 * Visit a parse tree produced by {@link gPracticaParser#whileLoop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileLoop(gPracticaParser.WhileLoopContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Div}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDiv(gPracticaParser.DivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Suma}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSuma(gPracticaParser.SumaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Mayor}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMayor(gPracticaParser.MayorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Mult}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMult(gPracticaParser.MultContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Bool}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBool(gPracticaParser.BoolContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Menor}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMenor(gPracticaParser.MenorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Var}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar(gPracticaParser.VarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Num}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum(gPracticaParser.NumContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Igualdad}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgualdad(gPracticaParser.IgualdadContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Resta}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitResta(gPracticaParser.RestaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Inc}
	 * labeled alternative in {@link gPracticaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInc(gPracticaParser.IncContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Or}
	 * labeled alternative in {@link gPracticaParser#bolOperation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOr(gPracticaParser.OrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code And}
	 * labeled alternative in {@link gPracticaParser#bolOperation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnd(gPracticaParser.AndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Xor}
	 * labeled alternative in {@link gPracticaParser#bolOperation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXor(gPracticaParser.XorContext ctx);
}