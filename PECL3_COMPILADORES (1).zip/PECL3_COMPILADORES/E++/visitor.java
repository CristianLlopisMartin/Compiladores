import java.util.*;
import java.io.IOException;


public class visitor extends gPracticaParserBaseVisitor<String> {
    int i =0;
    @Override
    public String visitProg(gPracticaParser.ProgContext ctx) {
        int columnCount = ctx.getChildCount();
        for(int i=0;i<columnCount;i++){
        System.out.println(visit(ctx.getChild(i)));}
        return "";
    }

    @Override
    public String visitIfCondicion(gPracticaParser.IfCondicionContext ctx) {
        return visit(ctx.condicion(0))+ visit(ctx.asignacion(0));
    }

    @Override
    public String visitCondicion(gPracticaParser.CondicionContext ctx) {
        return visit(ctx.expr(0));
    }

    @Override
    public String visitMayor(gPracticaParser.MayorContext ctx) {
        return visit(ctx.expr(0))+" \nistore_1"+ visit(ctx.expr(1))+" \nistore_2"+" \niload_1"+" \niload_2"+"\nif_icmpgt BODY"+"\nBODY:\n";
    }

    @Override
    public String visitMenor(gPracticaParser.MenorContext ctx) {
        return visit(ctx.expr(0))+" \nistore_1"+ visit(ctx.expr(1))+" \nistore_2"+" \niload_1"+" \niload_2"+"\nif_icmplt BODY"+"\nBODY: \n";
    }



    @Override
    public String visitAsignar(gPracticaParser.AsignarContext ctx) {
        return visit(ctx.expr(0)) + visit(ctx.expr(1));
    }

    @Override
    public String visitSuma(gPracticaParser.SumaContext ctx) {
        return visit(ctx.expr())  +"\nldc "+ctx.right.getText()+"\niadd" ;
    }

    @Override
    public String visitResta(gPracticaParser.RestaContext ctx) {
        return  visit(ctx.expr()) +"\nldc "+ctx.right.getText()+"\nires"  ;
    }

    @Override
    public String visitMult(gPracticaParser.MultContext ctx) {
        return  visit(ctx.expr()) +"\nldc "+ctx.right.getText()+"\nmult"  ;
    }


    @Override
    public String visitDiv(gPracticaParser.DivContext ctx) {
        return  visit(ctx.expr()) +"\nldc "+ctx.right.getText()+"\nidiv"  ;
    }

    @Override
    public String visitNum(gPracticaParser.NumContext ctx) {
        return "\nldc "+ctx.numero.getText();
    }

    @Override
    public String visitVar(gPracticaParser.VarContext ctx) {
        i++;
        return ".var"+i+" "+ctx.variable.getText();
    }

    @Override
    public String visitBool(gPracticaParser.BoolContext ctx) {
        return "\nldc "+ctx.boolean_.getText();
    }

    @Override
    public String visitXor(gPracticaParser.XorContext ctx) {
        return visit(ctx.expr(0)) + visit(ctx.expr(1))+"\nixor";
    }

    @Override
    public String visitOr(gPracticaParser.OrContext ctx) {
        return visit(ctx.expr(0)) + visit(ctx.expr(1))+"\nior";
    }

    @Override
    public String visitAnd(gPracticaParser.AndContext ctx) {
        return visit(ctx.expr(0)) + visit(ctx.expr(1))+"\niand";
    }
}