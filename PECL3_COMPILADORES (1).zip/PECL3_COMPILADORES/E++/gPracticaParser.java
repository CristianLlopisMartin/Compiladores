// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class gPracticaParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		MOSTRAR=1, FOR=2, WHILE=3, APAR=4, APCR=5, OR=6, XOR=7, AND=8, NEWLINE=9, 
		IGUAL=10, MAYOR=11, MENOR=12, IGUALDAD=13, VERDAD=14, FALSO=15, INC=16, 
		CONDICIONAL=17, DECISION=18, OPMUL=19, OPDIV=20, OPSUM=21, OPRES=22, INT=23, 
		FLOAT=24, FINAL=25, ASIGNAR=26, FIN=27, VARIABLE=28, COMENTARIOlinea=29, 
		COMENTARIOVlineas=30, WS=31, FINAL_COMENTARIO=32, LETRA=33, COMENTARIO_CERRAR=34, 
		LETRACOMEN=35;
	public static final int
		RULE_prog = 0, RULE_pantalla = 1, RULE_asignacion = 2, RULE_comentario = 3, 
		RULE_textos = 4, RULE_textos2 = 5, RULE_condicion = 6, RULE_ifCondicion = 7, 
		RULE_loopCondicion = 8, RULE_whileLoop = 9, RULE_expr = 10, RULE_bolOperation = 11;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "pantalla", "asignacion", "comentario", "textos", "textos2", 
			"condicion", "ifCondicion", "loopCondicion", "whileLoop", "expr", "bolOperation"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, "'#'", "'/*'", null, null, null, "'*/'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "MOSTRAR", "FOR", "WHILE", "APAR", "APCR", "OR", "XOR", "AND", 
			"NEWLINE", "IGUAL", "MAYOR", "MENOR", "IGUALDAD", "VERDAD", "FALSO", 
			"INC", "CONDICIONAL", "DECISION", "OPMUL", "OPDIV", "OPSUM", "OPRES", 
			"INT", "FLOAT", "FINAL", "ASIGNAR", "FIN", "VARIABLE", "COMENTARIOlinea", 
			"COMENTARIOVlineas", "WS", "FINAL_COMENTARIO", "LETRA", "COMENTARIO_CERRAR", 
			"LETRACOMEN"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public gPracticaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public List<BolOperationContext> bolOperation() {
			return getRuleContexts(BolOperationContext.class);
		}
		public BolOperationContext bolOperation(int i) {
			return getRuleContext(BolOperationContext.class,i);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public List<WhileLoopContext> whileLoop() {
			return getRuleContexts(WhileLoopContext.class);
		}
		public WhileLoopContext whileLoop(int i) {
			return getRuleContext(WhileLoopContext.class,i);
		}
		public List<LoopCondicionContext> loopCondicion() {
			return getRuleContexts(LoopCondicionContext.class);
		}
		public LoopCondicionContext loopCondicion(int i) {
			return getRuleContext(LoopCondicionContext.class,i);
		}
		public List<IfCondicionContext> ifCondicion() {
			return getRuleContexts(IfCondicionContext.class);
		}
		public IfCondicionContext ifCondicion(int i) {
			return getRuleContext(IfCondicionContext.class,i);
		}
		public List<PantallaContext> pantalla() {
			return getRuleContexts(PantallaContext.class);
		}
		public PantallaContext pantalla(int i) {
			return getRuleContext(PantallaContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(gPracticaParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(gPracticaParser.NEWLINE, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitProg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(40); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(35);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
				case 1:
					{
					setState(24);
					bolOperation();
					}
					break;
				case 2:
					{
					setState(25);
					expr(0);
					}
					break;
				case 3:
					{
					setState(26);
					asignacion();
					}
					break;
				case 4:
					{
					setState(27);
					whileLoop();
					}
					break;
				case 5:
					{
					setState(28);
					loopCondicion();
					}
					break;
				case 6:
					{
					setState(29);
					ifCondicion();
					}
					break;
				case 7:
					{
					setState(32);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case COMENTARIOlinea:
					case COMENTARIOVlineas:
						{
						setState(30);
						comentario();
						}
						break;
					case NEWLINE:
						{
						setState(31);
						match(NEWLINE);
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					break;
				case 8:
					{
					setState(34);
					pantalla();
					}
					break;
				}
				setState(38);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
				case 1:
					{
					setState(37);
					match(NEWLINE);
					}
					break;
				}
				}
				}
				setState(42); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 1954857490L) != 0 );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PantallaContext extends ParserRuleContext {
		public TerminalNode MOSTRAR() { return getToken(gPracticaParser.MOSTRAR, 0); }
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public PantallaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pantalla; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitPantalla(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PantallaContext pantalla() throws RecognitionException {
		PantallaContext _localctx = new PantallaContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_pantalla);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(44);
			match(MOSTRAR);
			setState(46); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(45);
				expr(0);
				}
				}
				setState(48); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0 );
			setState(50);
			match(FINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AsignacionContext extends ParserRuleContext {
		public AsignacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion; }
	 
		public AsignacionContext() { }
		public void copyFrom(AsignacionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AsignarContext extends AsignacionContext {
		public TerminalNode ASIGNAR() { return getToken(gPracticaParser.ASIGNAR, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode IGUAL() { return getToken(gPracticaParser.IGUAL, 0); }
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public AsignarContext(AsignacionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitAsignar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AsignacionContext asignacion() throws RecognitionException {
		AsignacionContext _localctx = new AsignacionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_asignacion);
		int _la;
		try {
			_localctx = new AsignarContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(52);
			match(ASIGNAR);
			setState(53);
			expr(0);
			setState(54);
			match(IGUAL);
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0) {
				{
				{
				setState(55);
				expr(0);
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(61);
			match(FINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComentarioContext extends ParserRuleContext {
		public TerminalNode COMENTARIOVlineas() { return getToken(gPracticaParser.COMENTARIOVlineas, 0); }
		public TerminalNode COMENTARIO_CERRAR() { return getToken(gPracticaParser.COMENTARIO_CERRAR, 0); }
		public List<Textos2Context> textos2() {
			return getRuleContexts(Textos2Context.class);
		}
		public Textos2Context textos2(int i) {
			return getRuleContext(Textos2Context.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(gPracticaParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(gPracticaParser.NEWLINE, i);
		}
		public TerminalNode COMENTARIOlinea() { return getToken(gPracticaParser.COMENTARIOlinea, 0); }
		public TerminalNode FINAL_COMENTARIO() { return getToken(gPracticaParser.FINAL_COMENTARIO, 0); }
		public List<TextosContext> textos() {
			return getRuleContexts(TextosContext.class);
		}
		public TextosContext textos(int i) {
			return getRuleContext(TextosContext.class,i);
		}
		public ComentarioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comentario; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitComentario(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComentarioContext comentario() throws RecognitionException {
		ComentarioContext _localctx = new ComentarioContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_comentario);
		int _la;
		try {
			setState(80);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COMENTARIOVlineas:
				enterOuterAlt(_localctx, 1);
				{
				setState(63);
				match(COMENTARIOVlineas);
				setState(68);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE || _la==LETRACOMEN) {
					{
					setState(66);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case LETRACOMEN:
						{
						setState(64);
						textos2();
						}
						break;
					case NEWLINE:
						{
						setState(65);
						match(NEWLINE);
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					setState(70);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(71);
				match(COMENTARIO_CERRAR);
				}
				break;
			case COMENTARIOlinea:
				enterOuterAlt(_localctx, 2);
				{
				setState(72);
				match(COMENTARIOlinea);
				setState(76);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==LETRA) {
					{
					{
					setState(73);
					textos();
					}
					}
					setState(78);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(79);
				match(FINAL_COMENTARIO);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TextosContext extends ParserRuleContext {
		public List<TerminalNode> LETRA() { return getTokens(gPracticaParser.LETRA); }
		public TerminalNode LETRA(int i) {
			return getToken(gPracticaParser.LETRA, i);
		}
		public TextosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textos; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitTextos(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TextosContext textos() throws RecognitionException {
		TextosContext _localctx = new TextosContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_textos);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(83); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(82);
					match(LETRA);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(85); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,10,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Textos2Context extends ParserRuleContext {
		public List<TerminalNode> LETRACOMEN() { return getTokens(gPracticaParser.LETRACOMEN); }
		public TerminalNode LETRACOMEN(int i) {
			return getToken(gPracticaParser.LETRACOMEN, i);
		}
		public Textos2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textos2; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitTextos2(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Textos2Context textos2() throws RecognitionException {
		Textos2Context _localctx = new Textos2Context(_ctx, getState());
		enterRule(_localctx, 10, RULE_textos2);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(88); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(87);
					match(LETRACOMEN);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(90); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CondicionContext extends ParserRuleContext {
		public TerminalNode CONDICIONAL() { return getToken(gPracticaParser.CONDICIONAL, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode DECISION() { return getToken(gPracticaParser.DECISION, 0); }
		public TerminalNode APAR() { return getToken(gPracticaParser.APAR, 0); }
		public TerminalNode APCR() { return getToken(gPracticaParser.APCR, 0); }
		public CondicionContext condicion() {
			return getRuleContext(CondicionContext.class,0);
		}
		public TerminalNode NEWLINE() { return getToken(gPracticaParser.NEWLINE, 0); }
		public CondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitCondicion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CondicionContext condicion() throws RecognitionException {
		return condicion(0);
	}

	private CondicionContext condicion(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		CondicionContext _localctx = new CondicionContext(_ctx, _parentState);
		CondicionContext _prevctx = _localctx;
		int _startState = 12;
		enterRecursionRule(_localctx, 12, RULE_condicion, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(109);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case VERDAD:
			case FALSO:
			case INT:
			case VARIABLE:
				{
				setState(94); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(93);
					expr(0);
					}
					}
					setState(96); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0 );
				setState(98);
				match(CONDICIONAL);
				}
				break;
			case DECISION:
				{
				setState(100);
				match(DECISION);
				}
				break;
			case APAR:
				{
				setState(101);
				match(APAR);
				setState(103); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(102);
					expr(0);
					}
					}
					setState(105); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0 );
				setState(107);
				match(APCR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(115);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CondicionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_condicion);
					setState(111);
					if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
					setState(112);
					match(NEWLINE);
					}
					} 
				}
				setState(117);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfCondicionContext extends ParserRuleContext {
		public List<CondicionContext> condicion() {
			return getRuleContexts(CondicionContext.class);
		}
		public CondicionContext condicion(int i) {
			return getRuleContext(CondicionContext.class,i);
		}
		public TerminalNode FIN() { return getToken(gPracticaParser.FIN, 0); }
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public IfCondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifCondicion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitIfCondicion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfCondicionContext ifCondicion() throws RecognitionException {
		IfCondicionContext _localctx = new IfCondicionContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_ifCondicion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(118);
			condicion(0);
			setState(123);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 344244240L) != 0) {
				{
				setState(121);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case APAR:
				case VERDAD:
				case FALSO:
				case DECISION:
				case INT:
				case VARIABLE:
					{
					setState(119);
					condicion(0);
					}
					break;
				case ASIGNAR:
					{
					setState(120);
					asignacion();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(125);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(126);
			match(FIN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LoopCondicionContext extends ParserRuleContext {
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public TerminalNode FOR() { return getToken(gPracticaParser.FOR, 0); }
		public CondicionContext condicion() {
			return getRuleContext(CondicionContext.class,0);
		}
		public TerminalNode FIN() { return getToken(gPracticaParser.FIN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public LoopCondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_loopCondicion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitLoopCondicion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LoopCondicionContext loopCondicion() throws RecognitionException {
		LoopCondicionContext _localctx = new LoopCondicionContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_loopCondicion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			asignacion();
			setState(129);
			match(FOR);
			setState(130);
			condicion(0);
			setState(134);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ASIGNAR) {
				{
				{
				setState(131);
				asignacion();
				}
				}
				setState(136);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(140);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0) {
				{
				{
				setState(137);
				expr(0);
				}
				}
				setState(142);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(143);
			match(FIN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WhileLoopContext extends ParserRuleContext {
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public TerminalNode WHILE() { return getToken(gPracticaParser.WHILE, 0); }
		public CondicionContext condicion() {
			return getRuleContext(CondicionContext.class,0);
		}
		public TerminalNode FIN() { return getToken(gPracticaParser.FIN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public WhileLoopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileLoop; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitWhileLoop(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileLoopContext whileLoop() throws RecognitionException {
		WhileLoopContext _localctx = new WhileLoopContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_whileLoop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145);
			asignacion();
			setState(146);
			match(WHILE);
			setState(147);
			condicion(0);
			setState(151);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ASIGNAR) {
				{
				{
				setState(148);
				asignacion();
				}
				}
				setState(153);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(157);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 276873216L) != 0) {
				{
				{
				setState(154);
				expr(0);
				}
				}
				setState(159);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(160);
			match(FIN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DivContext extends ExprContext {
		public ExprContext left;
		public Token right;
		public TerminalNode OPDIV() { return getToken(gPracticaParser.OPDIV, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public DivContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitDiv(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SumaContext extends ExprContext {
		public ExprContext left;
		public Token right;
		public TerminalNode OPSUM() { return getToken(gPracticaParser.OPSUM, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public SumaContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitSuma(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MayorContext extends ExprContext {
		public ExprContext left;
		public ExprContext right;
		public TerminalNode MAYOR() { return getToken(gPracticaParser.MAYOR, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public MayorContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitMayor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MultContext extends ExprContext {
		public ExprContext left;
		public Token right;
		public TerminalNode OPMUL() { return getToken(gPracticaParser.OPMUL, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public MultContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitMult(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BoolContext extends ExprContext {
		public Token boolean_;
		public TerminalNode VERDAD() { return getToken(gPracticaParser.VERDAD, 0); }
		public TerminalNode FALSO() { return getToken(gPracticaParser.FALSO, 0); }
		public BoolContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitBool(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MenorContext extends ExprContext {
		public ExprContext left;
		public ExprContext right;
		public TerminalNode MENOR() { return getToken(gPracticaParser.MENOR, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public MenorContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitMenor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VarContext extends ExprContext {
		public Token variable;
		public TerminalNode VARIABLE() { return getToken(gPracticaParser.VARIABLE, 0); }
		public VarContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitVar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NumContext extends ExprContext {
		public Token numero;
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public NumContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitNum(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IgualdadContext extends ExprContext {
		public ExprContext left;
		public ExprContext right;
		public TerminalNode IGUALDAD() { return getToken(gPracticaParser.IGUALDAD, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public IgualdadContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitIgualdad(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RestaContext extends ExprContext {
		public ExprContext left;
		public Token right;
		public TerminalNode OPRES() { return getToken(gPracticaParser.OPRES, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode INT() { return getToken(gPracticaParser.INT, 0); }
		public RestaContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitResta(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IncContext extends ExprContext {
		public ExprContext left;
		public Token inc;
		public ExprContext right;
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode INC() { return getToken(gPracticaParser.INC, 0); }
		public IncContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitInc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 20;
		enterRecursionRule(_localctx, 20, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(166);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				{
				_localctx = new NumContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(163);
				((NumContext)_localctx).numero = match(INT);
				}
				break;
			case VARIABLE:
				{
				_localctx = new VarContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(164);
				((VarContext)_localctx).variable = match(VARIABLE);
				}
				break;
			case VERDAD:
			case FALSO:
				{
				_localctx = new BoolContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(165);
				((BoolContext)_localctx).boolean_ = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==VERDAD || _la==FALSO) ) {
					((BoolContext)_localctx).boolean_ = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(196);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(194);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
					case 1:
						{
						_localctx = new MayorContext(new ExprContext(_parentctx, _parentState));
						((MayorContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(168);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(169);
						match(MAYOR);
						setState(170);
						((MayorContext)_localctx).right = expr(6);
						}
						break;
					case 2:
						{
						_localctx = new MenorContext(new ExprContext(_parentctx, _parentState));
						((MenorContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(171);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(172);
						match(MENOR);
						setState(173);
						((MenorContext)_localctx).right = expr(5);
						}
						break;
					case 3:
						{
						_localctx = new IgualdadContext(new ExprContext(_parentctx, _parentState));
						((IgualdadContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(174);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(175);
						match(IGUALDAD);
						setState(176);
						((IgualdadContext)_localctx).right = expr(4);
						}
						break;
					case 4:
						{
						_localctx = new SumaContext(new ExprContext(_parentctx, _parentState));
						((SumaContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(177);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(178);
						match(OPSUM);
						setState(179);
						((SumaContext)_localctx).right = match(INT);
						}
						break;
					case 5:
						{
						_localctx = new RestaContext(new ExprContext(_parentctx, _parentState));
						((RestaContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(180);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(181);
						match(OPRES);
						setState(182);
						((RestaContext)_localctx).right = match(INT);
						}
						break;
					case 6:
						{
						_localctx = new MultContext(new ExprContext(_parentctx, _parentState));
						((MultContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(183);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(184);
						match(OPMUL);
						setState(185);
						((MultContext)_localctx).right = match(INT);
						}
						break;
					case 7:
						{
						_localctx = new DivContext(new ExprContext(_parentctx, _parentState));
						((DivContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(186);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(187);
						match(OPDIV);
						setState(188);
						((DivContext)_localctx).right = match(INT);
						}
						break;
					case 8:
						{
						_localctx = new IncContext(new ExprContext(_parentctx, _parentState));
						((IncContext)_localctx).left = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(189);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(190);
						((IncContext)_localctx).inc = match(INC);
						setState(191);
						((IncContext)_localctx).right = expr(0);
						setState(192);
						match(FINAL);
						}
						break;
					}
					} 
				}
				setState(198);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BolOperationContext extends ParserRuleContext {
		public BolOperationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bolOperation; }
	 
		public BolOperationContext() { }
		public void copyFrom(BolOperationContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OrContext extends BolOperationContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode OR() { return getToken(gPracticaParser.OR, 0); }
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public OrContext(BolOperationContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitOr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AndContext extends BolOperationContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode AND() { return getToken(gPracticaParser.AND, 0); }
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public AndContext(BolOperationContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitAnd(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XorContext extends BolOperationContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode XOR() { return getToken(gPracticaParser.XOR, 0); }
		public TerminalNode FINAL() { return getToken(gPracticaParser.FINAL, 0); }
		public XorContext(BolOperationContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof gPracticaParserVisitor ) return ((gPracticaParserVisitor<? extends T>)visitor).visitXor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BolOperationContext bolOperation() throws RecognitionException {
		BolOperationContext _localctx = new BolOperationContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_bolOperation);
		try {
			setState(214);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				_localctx = new OrContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(199);
				expr(0);
				setState(200);
				match(OR);
				setState(201);
				expr(0);
				setState(202);
				match(FINAL);
				}
				break;
			case 2:
				_localctx = new AndContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(204);
				expr(0);
				setState(205);
				match(AND);
				setState(206);
				expr(0);
				setState(207);
				match(FINAL);
				}
				break;
			case 3:
				_localctx = new XorContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(209);
				expr(0);
				setState(210);
				match(XOR);
				setState(211);
				expr(0);
				setState(212);
				match(FINAL);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 6:
			return condicion_sempred((CondicionContext)_localctx, predIndex);
		case 10:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean condicion_sempred(CondicionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return precpred(_ctx, 5);
		case 2:
			return precpred(_ctx, 4);
		case 3:
			return precpred(_ctx, 3);
		case 4:
			return precpred(_ctx, 11);
		case 5:
			return precpred(_ctx, 10);
		case 6:
			return precpred(_ctx, 9);
		case 7:
			return precpred(_ctx, 8);
		case 8:
			return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001#\u00d9\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0001"+
		"\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001"+
		"\u0000\u0001\u0000\u0003\u0000!\b\u0000\u0001\u0000\u0003\u0000$\b\u0000"+
		"\u0001\u0000\u0003\u0000\'\b\u0000\u0004\u0000)\b\u0000\u000b\u0000\f"+
		"\u0000*\u0001\u0001\u0001\u0001\u0004\u0001/\b\u0001\u000b\u0001\f\u0001"+
		"0\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0005\u00029\b\u0002\n\u0002\f\u0002<\t\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0005\u0003C\b\u0003\n\u0003\f\u0003"+
		"F\t\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0005\u0003K\b\u0003\n\u0003"+
		"\f\u0003N\t\u0003\u0001\u0003\u0003\u0003Q\b\u0003\u0001\u0004\u0004\u0004"+
		"T\b\u0004\u000b\u0004\f\u0004U\u0001\u0005\u0004\u0005Y\b\u0005\u000b"+
		"\u0005\f\u0005Z\u0001\u0006\u0001\u0006\u0004\u0006_\b\u0006\u000b\u0006"+
		"\f\u0006`\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0004\u0006h\b\u0006\u000b\u0006\f\u0006i\u0001\u0006\u0001\u0006\u0003"+
		"\u0006n\b\u0006\u0001\u0006\u0001\u0006\u0005\u0006r\b\u0006\n\u0006\f"+
		"\u0006u\t\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0005\u0007z\b\u0007"+
		"\n\u0007\f\u0007}\t\u0007\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001"+
		"\b\u0001\b\u0005\b\u0085\b\b\n\b\f\b\u0088\t\b\u0001\b\u0005\b\u008b\b"+
		"\b\n\b\f\b\u008e\t\b\u0001\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\t\u0005"+
		"\t\u0096\b\t\n\t\f\t\u0099\t\t\u0001\t\u0005\t\u009c\b\t\n\t\f\t\u009f"+
		"\t\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0003\n\u00a7\b\n"+
		"\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0005"+
		"\n\u00c3\b\n\n\n\f\n\u00c6\t\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0003"+
		"\u000b\u00d7\b\u000b\u0001\u000b\u0000\u0002\f\u0014\f\u0000\u0002\u0004"+
		"\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0000\u0001\u0001\u0000\u000e"+
		"\u000f\u00f5\u0000(\u0001\u0000\u0000\u0000\u0002,\u0001\u0000\u0000\u0000"+
		"\u00044\u0001\u0000\u0000\u0000\u0006P\u0001\u0000\u0000\u0000\bS\u0001"+
		"\u0000\u0000\u0000\nX\u0001\u0000\u0000\u0000\fm\u0001\u0000\u0000\u0000"+
		"\u000ev\u0001\u0000\u0000\u0000\u0010\u0080\u0001\u0000\u0000\u0000\u0012"+
		"\u0091\u0001\u0000\u0000\u0000\u0014\u00a6\u0001\u0000\u0000\u0000\u0016"+
		"\u00d6\u0001\u0000\u0000\u0000\u0018$\u0003\u0016\u000b\u0000\u0019$\u0003"+
		"\u0014\n\u0000\u001a$\u0003\u0004\u0002\u0000\u001b$\u0003\u0012\t\u0000"+
		"\u001c$\u0003\u0010\b\u0000\u001d$\u0003\u000e\u0007\u0000\u001e!\u0003"+
		"\u0006\u0003\u0000\u001f!\u0005\t\u0000\u0000 \u001e\u0001\u0000\u0000"+
		"\u0000 \u001f\u0001\u0000\u0000\u0000!$\u0001\u0000\u0000\u0000\"$\u0003"+
		"\u0002\u0001\u0000#\u0018\u0001\u0000\u0000\u0000#\u0019\u0001\u0000\u0000"+
		"\u0000#\u001a\u0001\u0000\u0000\u0000#\u001b\u0001\u0000\u0000\u0000#"+
		"\u001c\u0001\u0000\u0000\u0000#\u001d\u0001\u0000\u0000\u0000# \u0001"+
		"\u0000\u0000\u0000#\"\u0001\u0000\u0000\u0000$&\u0001\u0000\u0000\u0000"+
		"%\'\u0005\t\u0000\u0000&%\u0001\u0000\u0000\u0000&\'\u0001\u0000\u0000"+
		"\u0000\')\u0001\u0000\u0000\u0000(#\u0001\u0000\u0000\u0000)*\u0001\u0000"+
		"\u0000\u0000*(\u0001\u0000\u0000\u0000*+\u0001\u0000\u0000\u0000+\u0001"+
		"\u0001\u0000\u0000\u0000,.\u0005\u0001\u0000\u0000-/\u0003\u0014\n\u0000"+
		".-\u0001\u0000\u0000\u0000/0\u0001\u0000\u0000\u00000.\u0001\u0000\u0000"+
		"\u000001\u0001\u0000\u0000\u000012\u0001\u0000\u0000\u000023\u0005\u0019"+
		"\u0000\u00003\u0003\u0001\u0000\u0000\u000045\u0005\u001a\u0000\u0000"+
		"56\u0003\u0014\n\u00006:\u0005\n\u0000\u000079\u0003\u0014\n\u000087\u0001"+
		"\u0000\u0000\u00009<\u0001\u0000\u0000\u0000:8\u0001\u0000\u0000\u0000"+
		":;\u0001\u0000\u0000\u0000;=\u0001\u0000\u0000\u0000<:\u0001\u0000\u0000"+
		"\u0000=>\u0005\u0019\u0000\u0000>\u0005\u0001\u0000\u0000\u0000?D\u0005"+
		"\u001e\u0000\u0000@C\u0003\n\u0005\u0000AC\u0005\t\u0000\u0000B@\u0001"+
		"\u0000\u0000\u0000BA\u0001\u0000\u0000\u0000CF\u0001\u0000\u0000\u0000"+
		"DB\u0001\u0000\u0000\u0000DE\u0001\u0000\u0000\u0000EG\u0001\u0000\u0000"+
		"\u0000FD\u0001\u0000\u0000\u0000GQ\u0005\"\u0000\u0000HL\u0005\u001d\u0000"+
		"\u0000IK\u0003\b\u0004\u0000JI\u0001\u0000\u0000\u0000KN\u0001\u0000\u0000"+
		"\u0000LJ\u0001\u0000\u0000\u0000LM\u0001\u0000\u0000\u0000MO\u0001\u0000"+
		"\u0000\u0000NL\u0001\u0000\u0000\u0000OQ\u0005 \u0000\u0000P?\u0001\u0000"+
		"\u0000\u0000PH\u0001\u0000\u0000\u0000Q\u0007\u0001\u0000\u0000\u0000"+
		"RT\u0005!\u0000\u0000SR\u0001\u0000\u0000\u0000TU\u0001\u0000\u0000\u0000"+
		"US\u0001\u0000\u0000\u0000UV\u0001\u0000\u0000\u0000V\t\u0001\u0000\u0000"+
		"\u0000WY\u0005#\u0000\u0000XW\u0001\u0000\u0000\u0000YZ\u0001\u0000\u0000"+
		"\u0000ZX\u0001\u0000\u0000\u0000Z[\u0001\u0000\u0000\u0000[\u000b\u0001"+
		"\u0000\u0000\u0000\\^\u0006\u0006\uffff\uffff\u0000]_\u0003\u0014\n\u0000"+
		"^]\u0001\u0000\u0000\u0000_`\u0001\u0000\u0000\u0000`^\u0001\u0000\u0000"+
		"\u0000`a\u0001\u0000\u0000\u0000ab\u0001\u0000\u0000\u0000bc\u0005\u0011"+
		"\u0000\u0000cn\u0001\u0000\u0000\u0000dn\u0005\u0012\u0000\u0000eg\u0005"+
		"\u0004\u0000\u0000fh\u0003\u0014\n\u0000gf\u0001\u0000\u0000\u0000hi\u0001"+
		"\u0000\u0000\u0000ig\u0001\u0000\u0000\u0000ij\u0001\u0000\u0000\u0000"+
		"jk\u0001\u0000\u0000\u0000kl\u0005\u0005\u0000\u0000ln\u0001\u0000\u0000"+
		"\u0000m\\\u0001\u0000\u0000\u0000md\u0001\u0000\u0000\u0000me\u0001\u0000"+
		"\u0000\u0000ns\u0001\u0000\u0000\u0000op\n\u0002\u0000\u0000pr\u0005\t"+
		"\u0000\u0000qo\u0001\u0000\u0000\u0000ru\u0001\u0000\u0000\u0000sq\u0001"+
		"\u0000\u0000\u0000st\u0001\u0000\u0000\u0000t\r\u0001\u0000\u0000\u0000"+
		"us\u0001\u0000\u0000\u0000v{\u0003\f\u0006\u0000wz\u0003\f\u0006\u0000"+
		"xz\u0003\u0004\u0002\u0000yw\u0001\u0000\u0000\u0000yx\u0001\u0000\u0000"+
		"\u0000z}\u0001\u0000\u0000\u0000{y\u0001\u0000\u0000\u0000{|\u0001\u0000"+
		"\u0000\u0000|~\u0001\u0000\u0000\u0000}{\u0001\u0000\u0000\u0000~\u007f"+
		"\u0005\u001b\u0000\u0000\u007f\u000f\u0001\u0000\u0000\u0000\u0080\u0081"+
		"\u0003\u0004\u0002\u0000\u0081\u0082\u0005\u0002\u0000\u0000\u0082\u0086"+
		"\u0003\f\u0006\u0000\u0083\u0085\u0003\u0004\u0002\u0000\u0084\u0083\u0001"+
		"\u0000\u0000\u0000\u0085\u0088\u0001\u0000\u0000\u0000\u0086\u0084\u0001"+
		"\u0000\u0000\u0000\u0086\u0087\u0001\u0000\u0000\u0000\u0087\u008c\u0001"+
		"\u0000\u0000\u0000\u0088\u0086\u0001\u0000\u0000\u0000\u0089\u008b\u0003"+
		"\u0014\n\u0000\u008a\u0089\u0001\u0000\u0000\u0000\u008b\u008e\u0001\u0000"+
		"\u0000\u0000\u008c\u008a\u0001\u0000\u0000\u0000\u008c\u008d\u0001\u0000"+
		"\u0000\u0000\u008d\u008f\u0001\u0000\u0000\u0000\u008e\u008c\u0001\u0000"+
		"\u0000\u0000\u008f\u0090\u0005\u001b\u0000\u0000\u0090\u0011\u0001\u0000"+
		"\u0000\u0000\u0091\u0092\u0003\u0004\u0002\u0000\u0092\u0093\u0005\u0003"+
		"\u0000\u0000\u0093\u0097\u0003\f\u0006\u0000\u0094\u0096\u0003\u0004\u0002"+
		"\u0000\u0095\u0094\u0001\u0000\u0000\u0000\u0096\u0099\u0001\u0000\u0000"+
		"\u0000\u0097\u0095\u0001\u0000\u0000\u0000\u0097\u0098\u0001\u0000\u0000"+
		"\u0000\u0098\u009d\u0001\u0000\u0000\u0000\u0099\u0097\u0001\u0000\u0000"+
		"\u0000\u009a\u009c\u0003\u0014\n\u0000\u009b\u009a\u0001\u0000\u0000\u0000"+
		"\u009c\u009f\u0001\u0000\u0000\u0000\u009d\u009b\u0001\u0000\u0000\u0000"+
		"\u009d\u009e\u0001\u0000\u0000\u0000\u009e\u00a0\u0001\u0000\u0000\u0000"+
		"\u009f\u009d\u0001\u0000\u0000\u0000\u00a0\u00a1\u0005\u001b\u0000\u0000"+
		"\u00a1\u0013\u0001\u0000\u0000\u0000\u00a2\u00a3\u0006\n\uffff\uffff\u0000"+
		"\u00a3\u00a7\u0005\u0017\u0000\u0000\u00a4\u00a7\u0005\u001c\u0000\u0000"+
		"\u00a5\u00a7\u0007\u0000\u0000\u0000\u00a6\u00a2\u0001\u0000\u0000\u0000"+
		"\u00a6\u00a4\u0001\u0000\u0000\u0000\u00a6\u00a5\u0001\u0000\u0000\u0000"+
		"\u00a7\u00c4\u0001\u0000\u0000\u0000\u00a8\u00a9\n\u0005\u0000\u0000\u00a9"+
		"\u00aa\u0005\u000b\u0000\u0000\u00aa\u00c3\u0003\u0014\n\u0006\u00ab\u00ac"+
		"\n\u0004\u0000\u0000\u00ac\u00ad\u0005\f\u0000\u0000\u00ad\u00c3\u0003"+
		"\u0014\n\u0005\u00ae\u00af\n\u0003\u0000\u0000\u00af\u00b0\u0005\r\u0000"+
		"\u0000\u00b0\u00c3\u0003\u0014\n\u0004\u00b1\u00b2\n\u000b\u0000\u0000"+
		"\u00b2\u00b3\u0005\u0015\u0000\u0000\u00b3\u00c3\u0005\u0017\u0000\u0000"+
		"\u00b4\u00b5\n\n\u0000\u0000\u00b5\u00b6\u0005\u0016\u0000\u0000\u00b6"+
		"\u00c3\u0005\u0017\u0000\u0000\u00b7\u00b8\n\t\u0000\u0000\u00b8\u00b9"+
		"\u0005\u0013\u0000\u0000\u00b9\u00c3\u0005\u0017\u0000\u0000\u00ba\u00bb"+
		"\n\b\u0000\u0000\u00bb\u00bc\u0005\u0014\u0000\u0000\u00bc\u00c3\u0005"+
		"\u0017\u0000\u0000\u00bd\u00be\n\u0002\u0000\u0000\u00be\u00bf\u0005\u0010"+
		"\u0000\u0000\u00bf\u00c0\u0003\u0014\n\u0000\u00c0\u00c1\u0005\u0019\u0000"+
		"\u0000\u00c1\u00c3\u0001\u0000\u0000\u0000\u00c2\u00a8\u0001\u0000\u0000"+
		"\u0000\u00c2\u00ab\u0001\u0000\u0000\u0000\u00c2\u00ae\u0001\u0000\u0000"+
		"\u0000\u00c2\u00b1\u0001\u0000\u0000\u0000\u00c2\u00b4\u0001\u0000\u0000"+
		"\u0000\u00c2\u00b7\u0001\u0000\u0000\u0000\u00c2\u00ba\u0001\u0000\u0000"+
		"\u0000\u00c2\u00bd\u0001\u0000\u0000\u0000\u00c3\u00c6\u0001\u0000\u0000"+
		"\u0000\u00c4\u00c2\u0001\u0000\u0000\u0000\u00c4\u00c5\u0001\u0000\u0000"+
		"\u0000\u00c5\u0015\u0001\u0000\u0000\u0000\u00c6\u00c4\u0001\u0000\u0000"+
		"\u0000\u00c7\u00c8\u0003\u0014\n\u0000\u00c8\u00c9\u0005\u0006\u0000\u0000"+
		"\u00c9\u00ca\u0003\u0014\n\u0000\u00ca\u00cb\u0005\u0019\u0000\u0000\u00cb"+
		"\u00d7\u0001\u0000\u0000\u0000\u00cc\u00cd\u0003\u0014\n\u0000\u00cd\u00ce"+
		"\u0005\b\u0000\u0000\u00ce\u00cf\u0003\u0014\n\u0000\u00cf\u00d0\u0005"+
		"\u0019\u0000\u0000\u00d0\u00d7\u0001\u0000\u0000\u0000\u00d1\u00d2\u0003"+
		"\u0014\n\u0000\u00d2\u00d3\u0005\u0007\u0000\u0000\u00d3\u00d4\u0003\u0014"+
		"\n\u0000\u00d4\u00d5\u0005\u0019\u0000\u0000\u00d5\u00d7\u0001\u0000\u0000"+
		"\u0000\u00d6\u00c7\u0001\u0000\u0000\u0000\u00d6\u00cc\u0001\u0000\u0000"+
		"\u0000\u00d6\u00d1\u0001\u0000\u0000\u0000\u00d7\u0017\u0001\u0000\u0000"+
		"\u0000\u001a #&*0:BDLPUZ`imsy{\u0086\u008c\u0097\u009d\u00a6\u00c2\u00c4"+
		"\u00d6";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}