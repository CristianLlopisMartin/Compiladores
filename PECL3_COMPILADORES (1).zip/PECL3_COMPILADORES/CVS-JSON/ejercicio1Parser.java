// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class ejercicio1Parser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		NEWLINE=1, CARACTERES=2, DECIMALES=3, NUMEROS=4, SEPARADORES=5, SIGNOS=6, 
		WS=7;
	public static final int
		RULE_prog = 0, RULE_separadores = 1, RULE_fecha = 2, RULE_decimales = 3, 
		RULE_numeros = 4, RULE_tring = 5, RULE_csv_linea = 6, RULE_lexema = 7, 
		RULE_pa = 8, RULE_signos = 9;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "separadores", "fecha", "decimales", "numeros", "tring", "csv_linea", 
			"lexema", "pa", "signos"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, "' '"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "NEWLINE", "CARACTERES", "DECIMALES", "NUMEROS", "SEPARADORES", 
			"SIGNOS", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public ejercicio1Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
	 
		public ProgContext() { }
		public void copyFrom(ProgContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PrincipalContext extends ProgContext {
		public Csv_lineaContext csv_linea() {
			return getRuleContext(Csv_lineaContext.class,0);
		}
		public PrincipalContext(ProgContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitPrincipal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		try {
			_localctx = new PrincipalContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(20);
			csv_linea();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SeparadoresContext extends ParserRuleContext {
		public TerminalNode SEPARADORES() { return getToken(ejercicio1Parser.SEPARADORES, 0); }
		public SeparadoresContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_separadores; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitSeparadores(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SeparadoresContext separadores() throws RecognitionException {
		SeparadoresContext _localctx = new SeparadoresContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_separadores);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(22);
			match(SEPARADORES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FechaContext extends ParserRuleContext {
		public List<TerminalNode> NUMEROS() { return getTokens(ejercicio1Parser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ejercicio1Parser.NUMEROS, i);
		}
		public List<SignosContext> signos() {
			return getRuleContexts(SignosContext.class);
		}
		public SignosContext signos(int i) {
			return getRuleContext(SignosContext.class,i);
		}
		public FechaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fecha; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitFecha(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FechaContext fecha() throws RecognitionException {
		FechaContext _localctx = new FechaContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_fecha);
		try {
			setState(36);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(24);
				match(NUMEROS);
				setState(25);
				signos();
				setState(26);
				match(NUMEROS);
				setState(27);
				signos();
				setState(28);
				match(NUMEROS);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(30);
				match(NUMEROS);
				setState(31);
				signos();
				setState(32);
				match(NUMEROS);
				setState(33);
				signos();
				setState(34);
				match(NUMEROS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DecimalesContext extends ParserRuleContext {
		public TerminalNode DECIMALES() { return getToken(ejercicio1Parser.DECIMALES, 0); }
		public DecimalesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decimales; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitDecimales(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DecimalesContext decimales() throws RecognitionException {
		DecimalesContext _localctx = new DecimalesContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_decimales);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(38);
			match(DECIMALES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumerosContext extends ParserRuleContext {
		public List<TerminalNode> NUMEROS() { return getTokens(ejercicio1Parser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ejercicio1Parser.NUMEROS, i);
		}
		public SignosContext signos() {
			return getRuleContext(SignosContext.class,0);
		}
		public DecimalesContext decimales() {
			return getRuleContext(DecimalesContext.class,0);
		}
		public NumerosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numeros; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitNumeros(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumerosContext numeros() throws RecognitionException {
		NumerosContext _localctx = new NumerosContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_numeros);
		try {
			setState(46);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(40);
				match(NUMEROS);
				setState(41);
				signos();
				setState(42);
				match(NUMEROS);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(44);
				match(NUMEROS);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(45);
				decimales();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TringContext extends ParserRuleContext {
		public FechaContext fecha() {
			return getRuleContext(FechaContext.class,0);
		}
		public NumerosContext numeros() {
			return getRuleContext(NumerosContext.class,0);
		}
		public List<TerminalNode> CARACTERES() { return getTokens(ejercicio1Parser.CARACTERES); }
		public TerminalNode CARACTERES(int i) {
			return getToken(ejercicio1Parser.CARACTERES, i);
		}
		public List<TerminalNode> WS() { return getTokens(ejercicio1Parser.WS); }
		public TerminalNode WS(int i) {
			return getToken(ejercicio1Parser.WS, i);
		}
		public List<SignosContext> signos() {
			return getRuleContexts(SignosContext.class);
		}
		public SignosContext signos(int i) {
			return getRuleContext(SignosContext.class,i);
		}
		public TringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tring; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitTring(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TringContext tring() throws RecognitionException {
		TringContext _localctx = new TringContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_tring);
		int _la;
		try {
			setState(68);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(48);
				fecha();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(49);
				numeros();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(50);
				match(CARACTERES);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(51);
				match(CARACTERES);
				setState(56);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==WS) {
					{
					{
					setState(52);
					match(WS);
					setState(53);
					match(CARACTERES);
					}
					}
					setState(58);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(59);
				match(CARACTERES);
				setState(65);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==SIGNOS) {
					{
					{
					setState(60);
					signos();
					setState(61);
					match(CARACTERES);
					}
					}
					setState(67);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Csv_lineaContext extends ParserRuleContext {
		public Csv_lineaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_csv_linea; }
	 
		public Csv_lineaContext() { }
		public void copyFrom(Csv_lineaContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LINEAContext extends Csv_lineaContext {
		public List<TerminalNode> NEWLINE() { return getTokens(ejercicio1Parser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(ejercicio1Parser.NEWLINE, i);
		}
		public List<LexemaContext> lexema() {
			return getRuleContexts(LexemaContext.class);
		}
		public LexemaContext lexema(int i) {
			return getRuleContext(LexemaContext.class,i);
		}
		public LINEAContext(Csv_lineaContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitLINEA(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Csv_lineaContext csv_linea() throws RecognitionException {
		Csv_lineaContext _localctx = new Csv_lineaContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_csv_linea);
		int _la;
		try {
			_localctx = new LINEAContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(71); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(70);
				lexema();
				}
				}
				setState(73); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 28L) != 0 );
			setState(75);
			match(NEWLINE);
			}
			setState(84); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(78); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(77);
					lexema();
					}
					}
					setState(80); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 28L) != 0 );
				setState(82);
				match(NEWLINE);
				}
				}
				setState(86); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 28L) != 0 );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LexemaContext extends ParserRuleContext {
		public LexemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lexema; }
	 
		public LexemaContext() { }
		public void copyFrom(LexemaContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PALABRAContext extends LexemaContext {
		public PaContext pa() {
			return getRuleContext(PaContext.class,0);
		}
		public SeparadoresContext separadores() {
			return getRuleContext(SeparadoresContext.class,0);
		}
		public PALABRAContext(LexemaContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitPALABRA(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LexemaContext lexema() throws RecognitionException {
		LexemaContext _localctx = new LexemaContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_lexema);
		int _la;
		try {
			_localctx = new PALABRAContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			pa();
			setState(90);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==SEPARADORES) {
				{
				setState(89);
				separadores();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PaContext extends ParserRuleContext {
		public List<TringContext> tring() {
			return getRuleContexts(TringContext.class);
		}
		public TringContext tring(int i) {
			return getRuleContext(TringContext.class,i);
		}
		public PaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pa; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitPa(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PaContext pa() throws RecognitionException {
		PaContext _localctx = new PaContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_pa);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(93); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(92);
					tring();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(95); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SignosContext extends ParserRuleContext {
		public TerminalNode SIGNOS() { return getToken(ejercicio1Parser.SIGNOS, 0); }
		public SignosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signos; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ejercicio1ParserVisitor ) return ((ejercicio1ParserVisitor<? extends T>)visitor).visitSignos(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SignosContext signos() throws RecognitionException {
		SignosContext _localctx = new SignosContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_signos);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(97);
			match(SIGNOS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0007d\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0003\u0002%\b\u0002\u0001\u0003\u0001\u0003\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0003\u0004/\b\u0004"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0005\u00057\b\u0005\n\u0005\f\u0005:\t\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0005\u0005@\b\u0005\n\u0005\f\u0005C\t\u0005"+
		"\u0003\u0005E\b\u0005\u0001\u0006\u0004\u0006H\b\u0006\u000b\u0006\f\u0006"+
		"I\u0001\u0006\u0001\u0006\u0001\u0006\u0004\u0006O\b\u0006\u000b\u0006"+
		"\f\u0006P\u0001\u0006\u0001\u0006\u0004\u0006U\b\u0006\u000b\u0006\f\u0006"+
		"V\u0001\u0007\u0001\u0007\u0003\u0007[\b\u0007\u0001\b\u0004\b^\b\b\u000b"+
		"\b\f\b_\u0001\t\u0001\t\u0001\t\u0000\u0000\n\u0000\u0002\u0004\u0006"+
		"\b\n\f\u000e\u0010\u0012\u0000\u0000g\u0000\u0014\u0001\u0000\u0000\u0000"+
		"\u0002\u0016\u0001\u0000\u0000\u0000\u0004$\u0001\u0000\u0000\u0000\u0006"+
		"&\u0001\u0000\u0000\u0000\b.\u0001\u0000\u0000\u0000\nD\u0001\u0000\u0000"+
		"\u0000\fG\u0001\u0000\u0000\u0000\u000eX\u0001\u0000\u0000\u0000\u0010"+
		"]\u0001\u0000\u0000\u0000\u0012a\u0001\u0000\u0000\u0000\u0014\u0015\u0003"+
		"\f\u0006\u0000\u0015\u0001\u0001\u0000\u0000\u0000\u0016\u0017\u0005\u0005"+
		"\u0000\u0000\u0017\u0003\u0001\u0000\u0000\u0000\u0018\u0019\u0005\u0004"+
		"\u0000\u0000\u0019\u001a\u0003\u0012\t\u0000\u001a\u001b\u0005\u0004\u0000"+
		"\u0000\u001b\u001c\u0003\u0012\t\u0000\u001c\u001d\u0005\u0004\u0000\u0000"+
		"\u001d%\u0001\u0000\u0000\u0000\u001e\u001f\u0005\u0004\u0000\u0000\u001f"+
		" \u0003\u0012\t\u0000 !\u0005\u0004\u0000\u0000!\"\u0003\u0012\t\u0000"+
		"\"#\u0005\u0004\u0000\u0000#%\u0001\u0000\u0000\u0000$\u0018\u0001\u0000"+
		"\u0000\u0000$\u001e\u0001\u0000\u0000\u0000%\u0005\u0001\u0000\u0000\u0000"+
		"&\'\u0005\u0003\u0000\u0000\'\u0007\u0001\u0000\u0000\u0000()\u0005\u0004"+
		"\u0000\u0000)*\u0003\u0012\t\u0000*+\u0005\u0004\u0000\u0000+/\u0001\u0000"+
		"\u0000\u0000,/\u0005\u0004\u0000\u0000-/\u0003\u0006\u0003\u0000.(\u0001"+
		"\u0000\u0000\u0000.,\u0001\u0000\u0000\u0000.-\u0001\u0000\u0000\u0000"+
		"/\t\u0001\u0000\u0000\u00000E\u0003\u0004\u0002\u00001E\u0003\b\u0004"+
		"\u00002E\u0005\u0002\u0000\u000038\u0005\u0002\u0000\u000045\u0005\u0007"+
		"\u0000\u000057\u0005\u0002\u0000\u000064\u0001\u0000\u0000\u00007:\u0001"+
		"\u0000\u0000\u000086\u0001\u0000\u0000\u000089\u0001\u0000\u0000\u0000"+
		"9E\u0001\u0000\u0000\u0000:8\u0001\u0000\u0000\u0000;A\u0005\u0002\u0000"+
		"\u0000<=\u0003\u0012\t\u0000=>\u0005\u0002\u0000\u0000>@\u0001\u0000\u0000"+
		"\u0000?<\u0001\u0000\u0000\u0000@C\u0001\u0000\u0000\u0000A?\u0001\u0000"+
		"\u0000\u0000AB\u0001\u0000\u0000\u0000BE\u0001\u0000\u0000\u0000CA\u0001"+
		"\u0000\u0000\u0000D0\u0001\u0000\u0000\u0000D1\u0001\u0000\u0000\u0000"+
		"D2\u0001\u0000\u0000\u0000D3\u0001\u0000\u0000\u0000D;\u0001\u0000\u0000"+
		"\u0000E\u000b\u0001\u0000\u0000\u0000FH\u0003\u000e\u0007\u0000GF\u0001"+
		"\u0000\u0000\u0000HI\u0001\u0000\u0000\u0000IG\u0001\u0000\u0000\u0000"+
		"IJ\u0001\u0000\u0000\u0000JK\u0001\u0000\u0000\u0000KL\u0005\u0001\u0000"+
		"\u0000LT\u0001\u0000\u0000\u0000MO\u0003\u000e\u0007\u0000NM\u0001\u0000"+
		"\u0000\u0000OP\u0001\u0000\u0000\u0000PN\u0001\u0000\u0000\u0000PQ\u0001"+
		"\u0000\u0000\u0000QR\u0001\u0000\u0000\u0000RS\u0005\u0001\u0000\u0000"+
		"SU\u0001\u0000\u0000\u0000TN\u0001\u0000\u0000\u0000UV\u0001\u0000\u0000"+
		"\u0000VT\u0001\u0000\u0000\u0000VW\u0001\u0000\u0000\u0000W\r\u0001\u0000"+
		"\u0000\u0000XZ\u0003\u0010\b\u0000Y[\u0003\u0002\u0001\u0000ZY\u0001\u0000"+
		"\u0000\u0000Z[\u0001\u0000\u0000\u0000[\u000f\u0001\u0000\u0000\u0000"+
		"\\^\u0003\n\u0005\u0000]\\\u0001\u0000\u0000\u0000^_\u0001\u0000\u0000"+
		"\u0000_]\u0001\u0000\u0000\u0000_`\u0001\u0000\u0000\u0000`\u0011\u0001"+
		"\u0000\u0000\u0000ab\u0005\u0006\u0000\u0000b\u0013\u0001\u0000\u0000"+
		"\u0000\n$.8ADIPVZ_";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}