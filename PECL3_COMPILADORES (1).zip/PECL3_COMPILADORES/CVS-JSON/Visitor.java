
import java.util.*;
import java.io.IOException;
import java.io.FileWriter;

public class Visitor extends ejercicio1ParserBaseVisitor<String> {

    @Override
    public String visitLINEA(ejercicio1Parser.LINEAContext ctx) {
        String objeto ="";
        Map<Integer, String> rowValues = new HashMap<>();
        int columnCount = ctx.getChildCount();
        String value ="";
        String value2 ="";
        int j=0;
        List<Integer> lista = new ArrayList<Integer>();

        for(int i=0;i<columnCount;i++) {
            value = visit(ctx.getChild(j));
            if (value !=null) {
                j++;
                rowValues.put(j, value);
            }
            else{}
        }
        int lineas=0;
        for(int i=j+1;i<columnCount;i++) {
            value2 = visit(ctx.getChild(i));
            if (value2 != null) {
                rowValues.put(i, value2);
                lista.add(i);
            } else {
                lineas++;
            }
        }

        int cabecera=0;
        objeto+=("[ ");
        for(int y=0;y<lineas;y++) {
            objeto+="{";
          for (int x = 1; x <= j; x++) {
              objeto+="'"+rowValues.get(x)+"'"+": " + "'"+rowValues.get(lista.get(cabecera))+"'"+" ,"+"\n";
              cabecera++;
            }
          objeto+=" }"+","+"\r\n";

        }
        objeto+=("  ]");

        try {
            FileWriter file = new FileWriter("c:\\antlr\\prueba.json");
            file.write(objeto);
            file.flush();
            file.close();
        } catch (IOException e) {}
        System.out.println(objeto);
        return "";
    }

    @Override
    public String visitPALABRA(ejercicio1Parser.PALABRAContext ctx) {
        return ctx.getChild(0).getText();
    }
}