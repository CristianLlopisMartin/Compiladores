import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.FileInputStream;
import java.io.InputStream;

public class Test{
    public static void main(String[] args) throws Exception{

        String inputFile= null;
        if(args.length>0) inputFile=args[0];
        InputStream is =System.in;
        if(inputFile!=null){

            is= new FileInputStream(inputFile);

        }

        ANTLRInputStream input = new ANTLRInputStream(is);
        ejercicio1Lexer lexer = new ejercicio1Lexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        ejercicio1Parser parser = new ejercicio1Parser(tokens);
        parser.setBuildParseTree(true);

        ParseTree tree=parser.prog();

        //System.out.println(tree.toStringTree(parser));

        Visitor nv = new Visitor();
        String resultado = nv.visit(tree);
    }
}