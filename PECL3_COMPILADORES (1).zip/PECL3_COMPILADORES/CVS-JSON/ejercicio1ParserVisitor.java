// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ejercicio1Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ejercicio1ParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by the {@code Principal}
	 * labeled alternative in {@link ejercicio1Parser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrincipal(ejercicio1Parser.PrincipalContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#separadores}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeparadores(ejercicio1Parser.SeparadoresContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#fecha}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFecha(ejercicio1Parser.FechaContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#decimales}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecimales(ejercicio1Parser.DecimalesContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#numeros}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumeros(ejercicio1Parser.NumerosContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#tring}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTring(ejercicio1Parser.TringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LINEA}
	 * labeled alternative in {@link ejercicio1Parser#csv_linea}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLINEA(ejercicio1Parser.LINEAContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PALABRA}
	 * labeled alternative in {@link ejercicio1Parser#lexema}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPALABRA(ejercicio1Parser.PALABRAContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#pa}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPa(ejercicio1Parser.PaContext ctx);
	/**
	 * Visit a parse tree produced by {@link ejercicio1Parser#signos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignos(ejercicio1Parser.SignosContext ctx);
}