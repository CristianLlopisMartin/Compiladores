import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class visitor extends formitasParserBaseVisitor<String> {
    Map<Integer, String> map = new HashMap<>();
    ArrayList<Integer> nlin = new ArrayList<Integer>();
    pantalla frame = new pantalla();
    int nlinea=0;
    int ncolum=00;

    @Override
    public String visitLinea(formitasParser.LineaContext ctx) {
        ArrayList<String> memory = new ArrayList<String>();
        int columnCount = ctx.getChildCount();
        for (int i = 1; i < columnCount; i++) {
            String value = visit(ctx.getChild(i));
            System.out.println(value);
           if(value!=null) {
                memory.add(value);
            }if(value==null){
               memory.add("linea");}}
        BufferedImage image = new BufferedImage(Integer.valueOf(memory.get(2)), Integer.valueOf(memory.get(2)), BufferedImage.TYPE_INT_RGB);
        frame.crearpantalla(Integer.valueOf(memory.get(0)), Integer.valueOf(memory.get(0)));
        int contador = 0;
        System.out.println(memory);
        int num = memory.size();
        int numero=0;
        for (int i = 4; i < num; i++) {
             if (memory.get(i).contains("circulo")) {
                 map.put(ncolum, "circulo"+nlinea);
                 ncolum++;
                 contador++;
            } else if (memory.get(i).contains("triangulo")) {
                 String form= "triangulo"+nlinea;
                 map.put(ncolum,form);
                 ncolum++;
                 contador++;
            } else if (memory.get(i).contains("cuadrado")) {
                 String formcua= "cuadrado"+nlinea;
                 map.put(ncolum, formcua);
                 ncolum++;
                 contador++;
             }if(memory.get(i).contains("linea")){
                nlinea++;
                nlin.add(nlinea);
            }
            Graphics g = frame.getGraphics();
            frame.pintar(g, 0, 0, Integer.valueOf(memory.get(2)), Integer.valueOf(memory.get(2)),nlin,map);
        }
        System.out.println(nlin);
        System.out.println(map);
        return " ";
    }

    @Override
    public String visitForma(formitasParser.FormaContext ctx) {
        return ctx.getText();
    }

    @Override
    public String visitSepa(formitasParser.SepaContext ctx) {
        return "|";
    }

    @Override
    public String visitNum(formitasParser.NumContext ctx) {
        return ctx.getText();
    }
}
