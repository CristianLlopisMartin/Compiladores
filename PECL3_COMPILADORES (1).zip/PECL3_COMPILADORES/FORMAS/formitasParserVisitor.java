// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link formitasParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface formitasParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link formitasParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(formitasParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Sepa}
	 * labeled alternative in {@link formitasParser#separadores}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSepa(formitasParser.SepaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Forma}
	 * labeled alternative in {@link formitasParser#figuras}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForma(formitasParser.FormaContext ctx);
	/**
	 * Visit a parse tree produced by {@link formitasParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(formitasParser.ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Num}
	 * labeled alternative in {@link formitasParser#numero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum(formitasParser.NumContext ctx);
	/**
	 * Visit a parse tree produced by {@link formitasParser#delinicio}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelinicio(formitasParser.DelinicioContext ctx);
	/**
	 * Visit a parse tree produced by {@link formitasParser#delfinal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelfinal(formitasParser.DelfinalContext ctx);
	/**
	 * Visit a parse tree produced by {@link formitasParser#inicio}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInicio(formitasParser.InicioContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Linea}
	 * labeled alternative in {@link formitasParser#lineaformas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLinea(formitasParser.LineaContext ctx);
	/**
	 * Visit a parse tree produced by {@link formitasParser#formas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormas(formitasParser.FormasContext ctx);
}