import java.awt.*;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.JFrame;

public class pantalla extends JFrame {

    public void crearpantalla( int width, int height) {
        setTitle("Dibujo");
        setSize(width, height);
        setVisible(true);
    }

    public void pintar(Graphics g, int x, int y, int ancho, int alto, ArrayList nlineas, Map<Integer,String> formas) {
        super.paint(g);
        for(int i=0;i <= nlineas.size();i++){
            y=(ancho*i+ancho);
            int posicion=1;
            for(int j=0;j<formas.size();j++){
                String formcirc="circulo"+i;
                String formcua="cuadrado"+i;
                String formtri="triangulo"+i;
                x=ancho*posicion;
                if(formas.get(j).contains(formcirc)){
                    g.drawOval(x, y, ancho, alto);
                    posicion++;
                }
                if(formas.get(j).contains(formcua)){
                    g.drawRect(x, y, ancho, alto);
                    posicion++;
                }
                if(formas.get(j).contains(formtri)){
                    int [] vx1 = {(ancho/2)+x, (ancho)+x, (0)+x};
                    int [] vy1 = {(0)+y, (ancho)+y, (ancho)+y};
                    g.drawPolygon(vx1, vy1, 3);
                    posicion++;
                }
            }
        }
    }
}








