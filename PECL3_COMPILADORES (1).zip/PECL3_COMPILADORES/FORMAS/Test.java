import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.FileInputStream;
import java.io.InputStream;




public class Test {
    public static void main(String[] args) throws Exception {
        String inputFile = null;
        if (args.length > 0) {
            inputFile = args[0];
        } else {
            System.err.println("Se debe especificar el nombre del archivo como argumento.");
            return;
        }

        InputStream is = System.in;
        if (inputFile != null) {
            try {
                is = new FileInputStream(inputFile);
            } catch (Exception e) {
                System.err.println("No se puede abrir el archivo especificado: " + inputFile);
                return;
            }
        }

        ANTLRInputStream input = new ANTLRInputStream(is);
        formitasLexer lexer = new formitasLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        formitasParser parser = new formitasParser(tokens);
        parser.setBuildParseTree(true);


        ParseTree tree = parser.prog();
        System.out.println(tree.toStringTree(parser));

       visitor nv = new visitor();
       String resultado = nv.visit(tree);
       //System.out.println(resultado);
    }
}