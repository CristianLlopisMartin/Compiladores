// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class formitasParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.11.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IMGDIM=1, SHPDIM=2, LINEA=3, DELINICIO=4, DELFINAL=5, NEWLINE=6, NUMEROS=7, 
		FORMAS=8, SEPARADORES=9, WS=10;
	public static final int
		RULE_prog = 0, RULE_separadores = 1, RULE_figuras = 2, RULE_expr = 3, 
		RULE_numero = 4, RULE_delinicio = 5, RULE_delfinal = 6, RULE_inicio = 7, 
		RULE_lineaformas = 8, RULE_formas = 9;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "separadores", "figuras", "expr", "numero", "delinicio", "delfinal", 
			"inicio", "lineaformas", "formas"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'imgdim:'", "'shpdim:'", null, null, null, null, null, null, null, 
			"' '"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IMGDIM", "SHPDIM", "LINEA", "DELINICIO", "DELFINAL", "NEWLINE", 
			"NUMEROS", "FORMAS", "SEPARADORES", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "java-escape"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public formitasParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgContext extends ParserRuleContext {
		public List<LineaformasContext> lineaformas() {
			return getRuleContexts(LineaformasContext.class);
		}
		public LineaformasContext lineaformas(int i) {
			return getRuleContext(LineaformasContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(formitasParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(formitasParser.NEWLINE, i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitProg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(29);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMGDIM) {
				{
				{
				{
				setState(20);
				lineaformas();
				}
				setState(24);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(21);
					match(NEWLINE);
					}
					}
					setState(26);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(31);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SeparadoresContext extends ParserRuleContext {
		public SeparadoresContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_separadores; }
	 
		public SeparadoresContext() { }
		public void copyFrom(SeparadoresContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SepaContext extends SeparadoresContext {
		public TerminalNode SEPARADORES() { return getToken(formitasParser.SEPARADORES, 0); }
		public SepaContext(SeparadoresContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitSepa(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SeparadoresContext separadores() throws RecognitionException {
		SeparadoresContext _localctx = new SeparadoresContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_separadores);
		try {
			_localctx = new SepaContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(32);
			match(SEPARADORES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FigurasContext extends ParserRuleContext {
		public FigurasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figuras; }
	 
		public FigurasContext() { }
		public void copyFrom(FigurasContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FormaContext extends FigurasContext {
		public TerminalNode FORMAS() { return getToken(formitasParser.FORMAS, 0); }
		public FormaContext(FigurasContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitForma(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FigurasContext figuras() throws RecognitionException {
		FigurasContext _localctx = new FigurasContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_figuras);
		try {
			_localctx = new FormaContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(34);
			match(FORMAS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public FigurasContext figuras() {
			return getRuleContext(FigurasContext.class,0);
		}
		public SeparadoresContext separadores() {
			return getRuleContext(SeparadoresContext.class,0);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_expr);
		try {
			setState(39);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NUMEROS:
				enterOuterAlt(_localctx, 1);
				{
				setState(36);
				numero();
				}
				break;
			case FORMAS:
				enterOuterAlt(_localctx, 2);
				{
				setState(37);
				figuras();
				}
				break;
			case SEPARADORES:
				enterOuterAlt(_localctx, 3);
				{
				setState(38);
				separadores();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumeroContext extends ParserRuleContext {
		public NumeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numero; }
	 
		public NumeroContext() { }
		public void copyFrom(NumeroContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NumContext extends NumeroContext {
		public TerminalNode NUMEROS() { return getToken(formitasParser.NUMEROS, 0); }
		public NumContext(NumeroContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitNum(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumeroContext numero() throws RecognitionException {
		NumeroContext _localctx = new NumeroContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_numero);
		try {
			_localctx = new NumContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(41);
			match(NUMEROS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DelinicioContext extends ParserRuleContext {
		public TerminalNode DELINICIO() { return getToken(formitasParser.DELINICIO, 0); }
		public DelinicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delinicio; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitDelinicio(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DelinicioContext delinicio() throws RecognitionException {
		DelinicioContext _localctx = new DelinicioContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_delinicio);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(43);
			match(DELINICIO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DelfinalContext extends ParserRuleContext {
		public TerminalNode DELFINAL() { return getToken(formitasParser.DELFINAL, 0); }
		public DelfinalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delfinal; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitDelfinal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DelfinalContext delfinal() throws RecognitionException {
		DelfinalContext _localctx = new DelfinalContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_delfinal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(45);
			match(DELFINAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InicioContext extends ParserRuleContext {
		public TerminalNode IMGDIM() { return getToken(formitasParser.IMGDIM, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SHPDIM() { return getToken(formitasParser.SHPDIM, 0); }
		public InicioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inicio; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitInicio(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InicioContext inicio() throws RecognitionException {
		InicioContext _localctx = new InicioContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_inicio);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			match(IMGDIM);
			setState(51);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(48);
					expr();
					}
					} 
				}
				setState(53);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			}
			setState(54);
			expr();
			setState(55);
			match(SHPDIM);
			setState(59);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 896L) != 0) {
				{
				{
				setState(56);
				expr();
				}
				}
				setState(61);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LineaformasContext extends ParserRuleContext {
		public LineaformasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lineaformas; }
	 
		public LineaformasContext() { }
		public void copyFrom(LineaformasContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LineaContext extends LineaformasContext {
		public TerminalNode IMGDIM() { return getToken(formitasParser.IMGDIM, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode SHPDIM() { return getToken(formitasParser.SHPDIM, 0); }
		public DelinicioContext delinicio() {
			return getRuleContext(DelinicioContext.class,0);
		}
		public DelfinalContext delfinal() {
			return getRuleContext(DelfinalContext.class,0);
		}
		public List<TerminalNode> LINEA() { return getTokens(formitasParser.LINEA); }
		public TerminalNode LINEA(int i) {
			return getToken(formitasParser.LINEA, i);
		}
		public LineaContext(LineaformasContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitLinea(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LineaformasContext lineaformas() throws RecognitionException {
		LineaformasContext _localctx = new LineaformasContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_lineaformas);
		int _la;
		try {
			int _alt;
			_localctx = new LineaContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(62);
			match(IMGDIM);
			setState(66);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(63);
					expr();
					}
					} 
				}
				setState(68);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			setState(69);
			expr();
			setState(70);
			match(SHPDIM);
			setState(74);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((_la) & ~0x3f) == 0 && ((1L << _la) & 896L) != 0) {
				{
				{
				setState(71);
				expr();
				}
				}
				setState(76);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(77);
			delinicio();
			setState(86); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(79); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(78);
						expr();
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(81); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(84);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LINEA) {
					{
					setState(83);
					match(LINEA);
					}
				}

				}
				}
				setState(88); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((_la) & ~0x3f) == 0 && ((1L << _la) & 896L) != 0 );
			setState(90);
			delfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormasContext extends ParserRuleContext {
		public DelinicioContext delinicio() {
			return getRuleContext(DelinicioContext.class,0);
		}
		public DelfinalContext delfinal() {
			return getRuleContext(DelfinalContext.class,0);
		}
		public List<LineaformasContext> lineaformas() {
			return getRuleContexts(LineaformasContext.class);
		}
		public LineaformasContext lineaformas(int i) {
			return getRuleContext(LineaformasContext.class,i);
		}
		public FormasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formas; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof formitasParserVisitor ) return ((formitasParserVisitor<? extends T>)visitor).visitFormas(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormasContext formas() throws RecognitionException {
		FormasContext _localctx = new FormasContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_formas);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(92);
			delinicio();
			setState(94); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(93);
				lineaformas();
				}
				}
				setState(96); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==IMGDIM );
			setState(98);
			delfinal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\ne\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0001\u0000\u0001\u0000\u0005\u0000\u0017\b"+
		"\u0000\n\u0000\f\u0000\u001a\t\u0000\u0005\u0000\u001c\b\u0000\n\u0000"+
		"\f\u0000\u001f\t\u0000\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0003\u0003(\b\u0003\u0001\u0004"+
		"\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0007"+
		"\u0001\u0007\u0005\u00072\b\u0007\n\u0007\f\u00075\t\u0007\u0001\u0007"+
		"\u0001\u0007\u0001\u0007\u0005\u0007:\b\u0007\n\u0007\f\u0007=\t\u0007"+
		"\u0001\b\u0001\b\u0005\bA\b\b\n\b\f\bD\t\b\u0001\b\u0001\b\u0001\b\u0005"+
		"\bI\b\b\n\b\f\bL\t\b\u0001\b\u0001\b\u0004\bP\b\b\u000b\b\f\bQ\u0001\b"+
		"\u0003\bU\b\b\u0004\bW\b\b\u000b\b\f\bX\u0001\b\u0001\b\u0001\t\u0001"+
		"\t\u0004\t_\b\t\u000b\t\f\t`\u0001\t\u0001\t\u0001\t\u0000\u0000\n\u0000"+
		"\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0000\u0000f\u0000\u001d\u0001"+
		"\u0000\u0000\u0000\u0002 \u0001\u0000\u0000\u0000\u0004\"\u0001\u0000"+
		"\u0000\u0000\u0006\'\u0001\u0000\u0000\u0000\b)\u0001\u0000\u0000\u0000"+
		"\n+\u0001\u0000\u0000\u0000\f-\u0001\u0000\u0000\u0000\u000e/\u0001\u0000"+
		"\u0000\u0000\u0010>\u0001\u0000\u0000\u0000\u0012\\\u0001\u0000\u0000"+
		"\u0000\u0014\u0018\u0003\u0010\b\u0000\u0015\u0017\u0005\u0006\u0000\u0000"+
		"\u0016\u0015\u0001\u0000\u0000\u0000\u0017\u001a\u0001\u0000\u0000\u0000"+
		"\u0018\u0016\u0001\u0000\u0000\u0000\u0018\u0019\u0001\u0000\u0000\u0000"+
		"\u0019\u001c\u0001\u0000\u0000\u0000\u001a\u0018\u0001\u0000\u0000\u0000"+
		"\u001b\u0014\u0001\u0000\u0000\u0000\u001c\u001f\u0001\u0000\u0000\u0000"+
		"\u001d\u001b\u0001\u0000\u0000\u0000\u001d\u001e\u0001\u0000\u0000\u0000"+
		"\u001e\u0001\u0001\u0000\u0000\u0000\u001f\u001d\u0001\u0000\u0000\u0000"+
		" !\u0005\t\u0000\u0000!\u0003\u0001\u0000\u0000\u0000\"#\u0005\b\u0000"+
		"\u0000#\u0005\u0001\u0000\u0000\u0000$(\u0003\b\u0004\u0000%(\u0003\u0004"+
		"\u0002\u0000&(\u0003\u0002\u0001\u0000\'$\u0001\u0000\u0000\u0000\'%\u0001"+
		"\u0000\u0000\u0000\'&\u0001\u0000\u0000\u0000(\u0007\u0001\u0000\u0000"+
		"\u0000)*\u0005\u0007\u0000\u0000*\t\u0001\u0000\u0000\u0000+,\u0005\u0004"+
		"\u0000\u0000,\u000b\u0001\u0000\u0000\u0000-.\u0005\u0005\u0000\u0000"+
		".\r\u0001\u0000\u0000\u0000/3\u0005\u0001\u0000\u000002\u0003\u0006\u0003"+
		"\u000010\u0001\u0000\u0000\u000025\u0001\u0000\u0000\u000031\u0001\u0000"+
		"\u0000\u000034\u0001\u0000\u0000\u000046\u0001\u0000\u0000\u000053\u0001"+
		"\u0000\u0000\u000067\u0003\u0006\u0003\u00007;\u0005\u0002\u0000\u0000"+
		"8:\u0003\u0006\u0003\u000098\u0001\u0000\u0000\u0000:=\u0001\u0000\u0000"+
		"\u0000;9\u0001\u0000\u0000\u0000;<\u0001\u0000\u0000\u0000<\u000f\u0001"+
		"\u0000\u0000\u0000=;\u0001\u0000\u0000\u0000>B\u0005\u0001\u0000\u0000"+
		"?A\u0003\u0006\u0003\u0000@?\u0001\u0000\u0000\u0000AD\u0001\u0000\u0000"+
		"\u0000B@\u0001\u0000\u0000\u0000BC\u0001\u0000\u0000\u0000CE\u0001\u0000"+
		"\u0000\u0000DB\u0001\u0000\u0000\u0000EF\u0003\u0006\u0003\u0000FJ\u0005"+
		"\u0002\u0000\u0000GI\u0003\u0006\u0003\u0000HG\u0001\u0000\u0000\u0000"+
		"IL\u0001\u0000\u0000\u0000JH\u0001\u0000\u0000\u0000JK\u0001\u0000\u0000"+
		"\u0000KM\u0001\u0000\u0000\u0000LJ\u0001\u0000\u0000\u0000MV\u0003\n\u0005"+
		"\u0000NP\u0003\u0006\u0003\u0000ON\u0001\u0000\u0000\u0000PQ\u0001\u0000"+
		"\u0000\u0000QO\u0001\u0000\u0000\u0000QR\u0001\u0000\u0000\u0000RT\u0001"+
		"\u0000\u0000\u0000SU\u0005\u0003\u0000\u0000TS\u0001\u0000\u0000\u0000"+
		"TU\u0001\u0000\u0000\u0000UW\u0001\u0000\u0000\u0000VO\u0001\u0000\u0000"+
		"\u0000WX\u0001\u0000\u0000\u0000XV\u0001\u0000\u0000\u0000XY\u0001\u0000"+
		"\u0000\u0000YZ\u0001\u0000\u0000\u0000Z[\u0003\f\u0006\u0000[\u0011\u0001"+
		"\u0000\u0000\u0000\\^\u0003\n\u0005\u0000]_\u0003\u0010\b\u0000^]\u0001"+
		"\u0000\u0000\u0000_`\u0001\u0000\u0000\u0000`^\u0001\u0000\u0000\u0000"+
		"`a\u0001\u0000\u0000\u0000ab\u0001\u0000\u0000\u0000bc\u0003\f\u0006\u0000"+
		"c\u0013\u0001\u0000\u0000\u0000\u000b\u0018\u001d\'3;BJQTX`";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}