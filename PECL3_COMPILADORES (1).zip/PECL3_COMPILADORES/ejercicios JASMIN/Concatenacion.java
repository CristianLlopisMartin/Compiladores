package ejercicios;

public class Concatenacion {
    public static void main(String[] args) {
        String texto = "El numero es ";
        int numero = 5;
        System.out.println(texto + " " + numero);
    }
}