package ejercicios;

public class OpLog {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;
        boolean resultado = a || b;
        System.out.println(resultado);
    }
}
