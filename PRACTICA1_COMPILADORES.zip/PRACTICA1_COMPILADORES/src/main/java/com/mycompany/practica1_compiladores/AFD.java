/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practica1_compiladores;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author cristM
 */
public class AFD {
    
        List<Character> alfabeto= new ArrayList(); 
        List<Integer> estados = new ArrayList();
        public Integer estadoInicial=0;
        List<Integer> estadosFinales =new ArrayList();
        HashMap<Integer,HashMap<Character,Integer>> matriz= new HashMap<Integer,HashMap<Character,Integer>>();
        
       
        public AFD(){
            
            this.alfabeto=alfabeto;
            this.estadoInicial=estadoInicial;
            this.estados=estados;
            this.estadosFinales=estadosFinales;
            this.matriz=matriz;
                  
        }
     
        public void establecerQi(){
            
            estadoInicial=0;
            
        }
        
        
         public Integer getSiguienteEstado(Integer estado,Character caracter){
            
            return matriz.get(estado).get(caracter);
        
        }
      
       public Boolean  isFinal(Integer estado){
        
            return estadosFinales.contains(estado);
        
        }
        
        
        public Integer getEstadoInicial(){
            
            return estadoInicial;
        }
        
        public void iniAlfabeto(){
            
             alfabeto.add(new Character('a'));
             alfabeto.add(new Character('b'));
             alfabeto.add(new Character('c'));
            
        }
        
        public void inicializarMatriz(){
            
           
                
                for (int i=0 ; i<=7;++i){

                matriz.put(i,new HashMap<Character,Integer>());
            
                }
                    matriz.put(0,new HashMap<Character,Integer>()); 
                    matriz.put(1,new HashMap<Character,Integer>()); 
                    matriz.put(2,new HashMap<Character,Integer>()); 
                    matriz.put(3,new HashMap<Character,Integer>()); 
                    matriz.put(4,new HashMap<Character,Integer>()); 
                    matriz.put(5,new HashMap<Character,Integer>()); 
                    matriz.put(6,new HashMap<Character,Integer>()); 
                    matriz.put(7,new HashMap<Character,Integer>()); 
                   
            
            
            
        }
        
        
        public void iniEf(){
            
             estadosFinales.add(new Integer(3));
             estadosFinales.add(new Integer(6));
             estadosFinales.add(new Integer(7));
            
        }
        
        public void iniE(){
            
           for (int i=0;i<7;++i){ 
                estados.add(new Integer(i));
        }
            
        }
    
        public void cargarMatriz(){
            
         matriz.get(0).put('a',1);
         matriz.get(1).put('a',2);
         matriz.get(1).put('b',3);
         matriz.get(2).put('a',2);
         matriz.get(2).put('b',4);
         matriz.get(3).put('a',5);
         matriz.get(3).put('c',6);
         matriz.get(4).put('c',6);
         matriz.get(5).put('b',7);
         matriz.get(7).put('a',5);
         
        }
        
}
