/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practica1_compiladores;
import com.mycompany.practica1_compiladores.Main;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 *
 * @author crist
 */
public class MaquinaEstados {
    
    Integer estadoActual;
    AFD automata;
  
    
    
    public MaquinaEstados(AFD automata){
        
        this.automata=automata;
        this.estadoActual=estadoActual;
      
        
    }
    
    public void inicializar(){
       
     estadoActual =0;       
     
    }
    
    public boolean acepta(Character caracter) throws Exception{
     Integer estadotemp=automata.getSiguienteEstado(this.estadoActual, caracter);
     //System.out.println(automata.getSiguienteEstado(this.estadoActual, caracter));
       if(estadotemp!=null){
           
           this.estadoActual=estadotemp;
          // System.out.println(this.estadoActual);
           return true;
           
       }
       if(caracter=='e'){
                        
                        System.out.println("ERROR CARACTER VACIO");
                        return false;
                        
                }
       return false;
    }
       
   
    
    public boolean esFinal(){
        
        return automata.isFinal(estadoActual);
        
    }
    
    
    public void compruebaCadena(String cadena) throws Exception{
        inicializar();
        String cadena_final=cadena.trim();
        for(int i=0;i<cadena_final.length();i++){ 
            
                //System.out.println(cadena.charAt(i));
               if(this.acepta(cadena_final.charAt(i))){
                if(this.esFinal()==true && i==cadena_final.length()-1){
                      System.out.println(cadena_final +" es valida");
                    }if(this.esFinal()==false && i==cadena_final.length()-1){
                      System.out.println(cadena_final +" no es valida");
                    }
                   
              }
               else{
                   System.out.println(cadena_final +" no es valida");
                   break;
                   
               }}
        
    
    }
    
    
       
    public boolean compruebaCadena2(String cadena) throws Exception{
        inicializar();
        boolean condicion=false;
        for(int i=0;i<cadena.length();i++){ 
            
                //System.out.println(cadena.charAt(i));
               if(this.acepta(cadena.charAt(i))){
                if(this.esFinal()==true && i==cadena.length()-1){
                      //System.out.println(cadena +" es valida");
                      condicion=true;
                    }if(this.esFinal()==false && i==cadena.length()-1){
                      //System.out.println(cadena +" no es valida");
                      condicion=false;
                    }
              }else{
                   //System.out.println(cadena +" no es valida");
                   break;
                   
               }}
        
    return condicion;
    }
    
   
    public int random(){
        
      Random r = new Random();
      int valorDado = r.nextInt(3);
      return valorDado;
      
    }
 
    
    public void generarCadenas(int longitud,int cantidad) throws Exception{
      List<String> alfabeto= new ArrayList();
      int contador=0;
      String cadena="";
        while(contador!=cantidad){
        for(int j =0;j<cantidad;j++){
        cadena="";
        for(int i=0;i<longitud;i++){

         cadena= cadena + automata.alfabeto.get(random());
        

        }
     inicializar();
      if(this.compruebaCadena2(cadena)==true){
             
            contador++;
            alfabeto.add(cadena);
        
      }}
     
    }
    
    System.out.println(alfabeto);
    
        
    }
    

    
    
    
    
    
    
    
}
