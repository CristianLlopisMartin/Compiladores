/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practica1_compiladores;
import com.mycompany.practica1_compiladores.MaquinaEstados;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author crist
 */
public class Main{   AFD afd= new AFD();

       static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
          AFD afd= new AFD();
          
          MaquinaEstados maq=new MaquinaEstados(afd);
        
       afd.iniAlfabeto();//Añade los caracteres al alfabeto
       afd.inicializarMatriz(); //Añade los estados a la matriz
       afd.iniE();//Añade todos los estados a una lista
       afd.iniEf();//Añade lo estados finales en una lista
       afd.cargarMatriz();//Añade a la matriz los saltos posibles
   
        
        int condicion=0;
        while(condicion!=3){
            
            System.out.println("1:COMPROBAR CADENAS");
            System.out.println("2:GENERAR CADENAS");
            System.out.println("3:SALIR");
            
            int valor = sc.nextInt();
            
            
         switch(valor){
             
             case 1:
             
                     System.out.println(afd.matriz);
                     System.out.println("INTROUZCA LA CADENA A COMPROBAR: ");
                     String cadena = sc.next();
                     String cadena_final=cadena.trim();
                     maq.compruebaCadena(cadena_final);
                     break;
             
             case 2: 
                     System.out.println(afd.matriz);
                     System.out.println("INTROUZCA LA LONGITUD DE LAS CADENAS: ");
                     int longitud = sc.nextInt();
                     if(longitud<=1){
                         
                         System.out.println("LA LONGITUD DE LA CADENA DEBE SER MINIMO 2. ");
                         break;
                         
                     }else{
                     System.out.println("INTROUZCA LA CANTIDAD DE  CADENAS: ");
                     int cantidad = sc.nextInt();
                     maq.generarCadenas(longitud,cantidad);
                     break;}
                 
             case 3 :
                 
                 condicion=3;
                 break;
                 
             default:
                 
                 System.out.println("No valido");
                 
                 
                 
             
             
         }
         
        }
             
             
             
             
         }
}
                 

        
        //System.out.println(afd.alfabeto);
        //System.out.println(afd.estados);
        //System.out.println(afd.estadosFinales);
        //System.out.println(afd.estadoInicial); 
      
        
      
     
       
        
        
        
        
        
   
        
                


    

